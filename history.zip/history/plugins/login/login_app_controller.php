<?php

App::import('Vendor', 'facebook/facebook');


class LoginAppController extends AppController {

    var $helpers = array('Form', 'Javascript', 'Item', 'Crumb');
    var $uses = array('User', 'Event');
    var $user;
    var $components = array('Cookie', 'Auth', 'AuthExtension', 'Facebook', 'RequestHandler', 'MobileDetection', 'Helper');

	function beforeFilter() {
	
    	if( $this->isLayoutType('service') )
		{
			$this->Auth->allow('*');
			return;
		}

		$this->verifyUser();
		
    	//$this->RequestHandler->setContent('json', 'text/x-json');
		
		if( $this->Facebook->shouldClearCookie($this->LoggedUser(), $this->isLayoutType('facebook')) )
		{    	
			//Debugger::dump("deleted facebook user");
			$this->logoutUser();
			$this->Facebook->clearCookie();
		}
		
		$this->handleFBUser();
		
		$this->setLayout();
    	
    	$userData = null;
    	$userData = null;
    	$currentUser = $this->LoggedUser();
    	
		if($currentUser != null)
		{
			$userData = $this->User->getByID($currentUser['id']);
			$userData = $userData['User'];
		
		
			if( isset($userData) )
			{
				$userData['Favorites'] = $this->Event->getFavoritesByID($userData['id']);

				if( $userData['fbid'] != 0)
				{
					 $this->setupFbFriends();
				}
				
				$userData['Friends'] = $this->User->getFriends($userData['id']);
			}
		}
			
		$this->set('user', $userData);
		$this->user = $userData;

		$this->set('day', date("d"));
		$this->set('month', date("m"));
        //$this->loadModel("Category");
		//$this->set('categoriesList', ClassRegistry::init('Category')->getCategories());
		
		$this->set('facebook', $this->Facebook->facebook);
 		
        $this->Auth->allow('*');
		$this->set('layout', $this->layout);
		
		$meta_description = "www.todayhistory.net is dedicated to sharing world history and personally significant \"historical\" information. Sign up now so you can share the fun of what happened today or any day for that matter";
		$meta_keywords = "happened today in history, events today in history, births today in history, what happend today in history, famous people history, events history, timelines, personal timelines, this day in history, history today";
		
		$this->set('meta_description', $meta_description);
		$this->set('meta_keywords', $meta_keywords);
		
		$this->set('Event', $this->Event);
	}
	

    private function verifyUser()
    {
    	$user = $this->LoggedUser();
	
		
		if( !isset($user) )
			return;
		else 
		{
			if( !is_array($user) )
				$this->logoutUser();
			else if(!array_key_exists('id', $user) )
				$this->logoutUser();
		}
    }
  
    
    private function setLayout() 
    {
		if( $this->isLayoutType('iphone') )
		{
			$this->layout = 'iphone';
		}
		else if( $this->isLayoutType('test') )
		{
			$this->layout = 'test';
		}
		else if( $this->isLayoutType('mobile') )
		{
			$this->layout = 'mobile';
			$this->Helper->isMobile = true;
		}
    }
    
  
    private function handleFBUser() {
     	$currentUser = $this->LoggedUser();
	
     	if( isset($currentUser) )
     	{
			return;
		}
        
        $fb_id = $this->Facebook->GetUser();
        
	    //$fb_id = '100000285823686';
	    
       if($fb_id)
        {			
            $user_record = $this->User->getByFBID($fb_id);    

     		//create new user
            if(empty($user_record))
            {
				$userInfo = $this->Facebook->getUserData($fb_id);
				$userInfo['birthdate'] = $this->User->changeDate($userInfo['birthday_date']);
				$userInfo['url'] = $this->User->changeURL($userInfo['url']);
				
				$user_record['User']['fbid'] = $fb_id;
				$user_record['User']['username'] = $userInfo['username'];
				$user_record['User']['name'] = $userInfo['name'];
				$user_record['User']['about_me'] = $userInfo['about_me'];
				$user_record['User']['birthdate'] = $userInfo['birthdate'];
				$user_record['User']['gender'] = $userInfo['gender'];
				$user_record['User']['url'] = $userInfo['website'];
				
				foreach($user_record['User'] as $field => $key)
				{
					if($user_record['User'][$field] == null)
						$user_record['User'][$field] = "";
				}
				
                $this->User->create();
				$this->User->set($user_record);
				
				if(empty($user_record['User']['username']))
					$this->Session->setFlash('Unable to log you in at this time, if the issue persists please contact us.', 'default', array('class' => 'success'));
           
				unset($this->User->validate);
                
                $this->User->save($user_record);        		
                $this->loginWithUserData($user_record);
                $this->Session->setFlash('You\'ve successfully logged in.', 'default', array('class' => 'success'));
             
                return;
            }
            //update user
            else
            {
            	
            	$userInfo = $this->Facebook->getUserData($fb_id);
				$userInfo['birthdate'] = $this->User->changeDate($userInfo['birthday_date']);
				$userInfo['url'] = $this->User->changeURL($userInfo['url']);

				if($updatedFields = $this->User->shouldUpdateUser($userInfo, $user_record['User'], array('name', 'username', 'birthdate', 'about_me', 'gender', 'url')))
				{
					$this->User->validationSet = 'Edit';
					
					$userID = $user_record['User']['id'];
					
					unset($user_record['User']);
					$user_record['User']['id'] = $userID;
					foreach($updatedFields as $field)
					{
						$user_record['User'][$field] = $userInfo[$field];
					}
					
					$validators = array();
					foreach($updatedFields as $field)
					{
						if(array_key_exists($field,$this->User->validateEdit))
							$validators[$field] = $this->User->validateEdit[$field];
					}
					unset($this->User->validateEdit);
					
					$this->User->validateEdit = $validators;
					$this->User->set($user_record);
					if(!$this->User->validates())
					{
						$invalidFields = $this->User->invalidFields();

						foreach($invalidFields as $field => $key)
						{
							unset($user_record['User'][$field]);
						}
						
						$this->User->create();
						$this->User->set($user_record);
					}
					
					if($this->User->validates())
					{
						$this->User->save($user_record); 
					}
               	 }
               	 	
           	}
   
           	$this->loginWithUserData($user_record);
            $this->Session->setFlash('You\'ve successfully logged in.', 'default', array('class' => 'success'));
            
           
		}
     }
   	
   	function setupFbFriends()
   	{
   		$loaded = $this->Session->read("loaded_fb");

		if( $loaded != 1)
		{
			$currentUser = $this->LoggedUser();
			
			try
			{
				$friends = $this->Facebook->getFriends($currentUser);
			}
			catch (Exception $ex) {
				$friends = null;
			}
			
			if($friends != null)
				$friendResults = $this->User->setupFBFriends($currentUser['id'], $friends);
				
			$this->Session->write("loaded_fb", 1);
		}
   	}
   	
   	function isLayoutType($type)
   	{
		if(isset($this->params[$type]))
			return true;
		else
			return false;
   	}
   	
   	function hasRiddles()
   	{
   		
   		if(!$this->isLoggedIn())
   		{
   			return false;
   		}
   		else
   		{
   			$loggedUser = $this->LoggedUser();
   			
   			if($loggedUser['riddle_amount'] > 0)
   				return true;
   			else
   				return false;
   		}
   	}
   	
   	function isLoggedIn()
   	{
   		$loggedUser = $this->Cookie->read(Configure::read('userSession'));
   		
   		//Debugger::dump( $loggedUser );
   		
   		return !is_null($loggedUser);
   	}

	
	function loginByUserID($userID)
    {

    	$this->recursive = 0;
    	$userData = $this->LoginUser->getByID($userID);
    	$this->loginWithUserData($userData);
    }
    
    function loginByFbid($fbID)
    {
    	$this->recursive = -1;
    	$userData = $this->User->getByFBID($fbID);
    	$this->loginWithUserData($userData);
    }
    
    function loginByPhoneID($userID, $phoneID)
    {
    	$this->recursive = 0;
    	$userData = $this->User->getByID($userID);
    	
    	//Debugger::dump( $userData['User'] );
    	if($userData['User']['iphone_id'] != $phoneID)
    	{
    		return;
    	}

    	$this->loginWithUserData($userData);
    }
   	
   	function loginWithUserData($userData)
   	{
		//Debugger::dump("Logged in");
   		//Debugger::dump($userData['User']);
    	
    	if( array_key_exists('about_me', $userData['User']) )
    	{
    		$userData['User']['about_me'] = urlencode($userData['User']['about_me']);
    	}
    	
    	$this->Cookie->write(Configure::read('userSession'), $userData['User']);  
   	}
   	
   	function logoutUser()
    {
    
    	$this->Cookie->delete(Configure::read('userSession'));
    	//$this->Cookie->write(Configure::read('userSession'),0);
   	}
   	
   	function LoggedUser()
   	{
   		$user = $this->Cookie->read(Configure::read('userSession'));
   		
   		if( !is_array($user) )
   			return null;
   		
   		if( array_key_exists('about_me', $user) )
    	{
    		$user['about_me'] = urldecode($user['about_me']);
    	}
    	return $user;
   	}
   	
   	function refreshUser($user)
   	{
   		//Debugger::dump("refreshed");
   		
   		$this->Cookie->write(Configure::read('userSession'), $user);  
   	}
   	
   	function LoggedUserID()
   	{
   		$loggedUser = $this->LoggedUser();
   		return $loggedUser['id'];
   	}
   	
   	function UpdateField($object, $field)
   	{
   		$data = array(
        	'User' => array(
             	'id'          =>    $object['User']['id'],
            	$field   =>    $object['User'][$field]
          	)
       	);
					
		$this->User->save( $data, false, array($field));
   	}
   	
   	function handleUser()
	{
		$iphone_id = null;
		$user_id = null;
		
		//Debugger::dump("Handle User");
		
		if( isset($this->params['url']['iphone_id']) )
		{
			$iphone_id = $this->params['url']['iphone_id'];
		}
		
		if( isset($this->params['url']['user_id']) )
		{
			$user_id = $this->params['url']['user_id'];
		}
		
		//Debugger::dump( $this->isLoggedIn() );
		
		if( $this->isLoggedIn() && isset($user_id) )
		{

			//Debugger::dump("Logged User");
			$loggedUser = $this->LoggedUser();
			//Debugger::dump( $loggedUser);
			if($loggedUser['id'] != $user_id)
			{
				//Debugger::dump("Logout");
				$this->logoutUser();
			}
		}
		
		if(!$this->isLoggedIn())
		{
			if( isset($iphone_id) && isset($user_id) )
			{
				$this->loginByPhoneID($user_id, $iphone_id);
			}
		}
		
	}
	
	function setupJSON() {
		$this->viewPath .= '/json';
        $this->layoutPath = 'json';  
        $this->action = "output";
	}
}
?>