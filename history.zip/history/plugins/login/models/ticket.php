<?php 
class Ticket extends AppModel
{
    var $name = 'Ticket';    
}
?>