<?php
class Submit extends AppModel {
  var $name = "Submit";
  var $useTable = false; 
 }
?>