<?php
class Event extends AppModel {
	var $name = 'Event';
	var $displayField = 'title';
	var $itemType = '3';
	
	var $belongsTo = array(
		'Category' => array(
			'className' => 'Category',
			'foreignKey' => 'category_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'User' => array(
			'className' => 'User',
			'foreignKey' => 'user_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		)
	);
	
	var $hasAndBelongsToMany = array('Links' => 
                     array('className'   => 'Link',
                           'joinTable' => 'events_links',
						  	'foreignKey' => 'event_id',
							'associationForeignKey' => 'link_id',
							'unique' => true,
							'type' => 'INNER'
              		 )   
	); 

	var $belongsToMany = array( 'Favorites' =>
        array(
            'className' => 'User'
        )
    );
    	
	var $validate = array(
		'event' => array(
			'minLength' => array(
				'required' => true,
				'rule' => array('minLength', 5),
				'last' => true,
				'message' => 'Event: Must be longer than 5 characters'
			),
		),
		'day' => array(
			'confirmDate' => array(
				'rule' => array('confirmDate'),
				'message' =>  'Date: Is not valid'
			)
		)
	);
	
	var $validateUser = array(
		'name' => array(
			'minLength' => array(
				'rule' => array('minLength', 2),
				'required' => true,
				'message' => 'Name: Must be valid'
			),
			'maxLength' => array(
				'rule' => array('maxLength', 50),
				'required' => true,
				'message' => 'Name: Is too long'
			)
		),
		'event' => array(
			'minLength' => array(
				'required' => true,
				'rule' => array('minLength', 5),
				'last' => true,
				'message' => 'Event: Must be longer than 5 characters'
			),
		),
		'day' => array(
			'confirmDate' => array(
				'rule' => array('confirmDate'),
				'message' =>  'Date: Is not valid'
			)
		)
	);
	
	var $validateHoliday = array(
		'event' => array(
			'minLength' => array(
				'required' => true,
				'rule' => array('minLength', 5),
				'last' => true,
				'message' => 'Event - Must be longer than 5 characters'
			),
		),
		'day' => array(
			'confirmHolidayDate' => array(
				'rule' => array('confirmHolidayDate'),
				'message' =>  'Date is not valid',
			)
		)
	);
	
        
    var $fields = array('Event.id', 'Event.name', 'Event.event', 'Event.day', 'Event.month', 'Event.year', 'Event.status',
    					'Category.id', 'Category.name',
						'User.id', 'User.username', 'User.admin',
						'(SELECT COUNT(id) FROM comments as Comment WHERE Comment.foreign_key = Event.id AND Comment.type = \'3\') as comment_count');
	var $amount = 20;
		
	function confirmDate()
	{
		$day = $this->data['Event']['day'];
		$month = $this->data['Event']['month'];
		$year = $this->data['Event']['year'];
		
		if( empty( $day ) || empty( $month ) || empty( $year ))
			return false;
			
		if( !is_numeric( $day ) || !is_numeric( $month ) || !is_numeric( $year ))
			return false;
			
		if( $year < 0)
		{
			if($day == 29 && $month == 2)
				return true;
				
			return checkdate($month, $day, 2010);
		}
		else
		{
			if($year > date("Y"))
				return false;
				
			return checkdate($month, $day, $year);
		}

		
		return false;
	}
	
	function confirmHolidayDate()
	{
		$day = $this->data['Event']['day'];
		$month = $this->data['Event']['month'];
		
		if( empty( $day ) || empty( $month ))
			return false;
			
		if( !is_numeric( $day ) || !is_numeric( $month ))
			return false;
			
	
		if($day == 29 && $month == 2)
			return true;
				
		return checkdate($month, $day, 2010);
	}
	
	
    function getByID($id) {
		
		$this->recursive = 2;
		
		$params = array(
			'fields' => $this->fields,
			'conditions' => array('Event.id' => $id),
			//'cache' => 'event_' . $id,
			//'cacheConfig' => 'medium'
		);

		return $this->find('first', $params);
	}
	
	function getByDate($day, $month, $category) {
		
		$categoryID = $this->Category->getIDForName($category);
		$this->recursive = 2;
		
		$params = array(
			'fields' => $this->fields,
			'conditions' => array('Event.day' => $day, 'Event.month' => $month, 'Event.category_id' => $categoryID, 'Event.status' => 1),
			'order' => array('year' => 'desc'),
			//'limit' => $this->amount
			//'cache' => 'event_' . $id,
			//'cacheConfig' => 'medium'
		);

		return $this->find('all', $params);
	}
	
	/*
	function getByFriends($day, $month, $category, $user_id) {
		
		$categoryID = $this->Category->getIDForName($category);
		$this->recursive = 2;
		
		$params = array(
			'fields' => $this->fields,
			'conditions' => array(
						array('or' =>
						array('Event.user_id' => $user_id, 'Friends.user_id' => $user_id)
					),
					'Event.day' => $day, 'Event.month' => $month, 'Event.category_id' => $categoryID, 'Event.status' => 3),
			'order' => array('year' => 'desc'),
			'joins' => array(
				array(
					'table' => 'users_friends', 					
					'type' => 'LEFT',
					'alias' => 'Friends',
					'conditions' => array(
						'Friends.friend_id = Event.user_id',
						'Friends.user_id = '. $user_id
						)
				)
			)
			//'cache' => 'event_' . $id,
			//'cacheConfig' => 'medium'
		);

		return $this->find('all', $params);
	}
	*/
	
	function getByFriends($day, $month, $category, $user_id) {
		
		$categoryID = $this->Category->getIDForName($category);
		
		if($categoryID == 36)
		{
			$orArray = array(
						array('Friends.user_id' => $user_id, 'Friends.friend_id = Event.user_id', 'Event.status' =>  3)
					);
		}
		else
		{
			$orArray = array(
						array('Friends.user_id' => $user_id, 'Event.user_id != ' . $user_id, 'Event.status' =>  3, 'Event.category_id' => $categoryID),
					);
		}
		
		$this->recursive = 2;
	
		$params = array(
			'fields' => $this->fields,
			'conditions' => array(
					'Event.day' => $day, 
					'Event.month' => $month,
					'or' => $orArray
					),
			'order' => array('year' => 'desc'),
			'joins' => array(
				array(
					'table' => 'users_friends', 					
					'type' => 'LEFT',
					'alias' => 'Friends',
					'conditions' => array(
						'or' => array(
							'Friends.user_id = Event.user_id',
							'Friends.friend_id = Event.user_id'
						)
					)
				)
			)
		);

		$friends = $this->find('all', $params);
		
		if($categoryID == 36)
		{
			$params = array(
				'fields' => $this->fields,
				'conditions' => array(
					'Event.user_id' => $user_id,
					'Event.day' => $day, 
					'Event.month' => $month,
					'Event.category_id != 37', 
					'or' => array(
							array('Event.status' =>  3),
							array('Event.status' =>  4),
							array('Event.status' =>  5)
						)
					),
				'order' => array('year' => 'desc'),
			);
		}
		else
		{
			$params = array(
				'fields' => $this->fields,
				'conditions' => array(
					'Event.user_id' => $user_id,
					'Event.day' => $day, 
					'Event.month' => $month,
					'Event.category_id' => $categoryID,
					'or' => array(
							array('Event.status' =>  3),
							array('Event.status' =>  4),
							array('Event.status' =>  5)
						)
					),
				'order' => array('year' => 'desc'),
			);
		}

		$personal = $this->find('all', $params);
		
		if(count($personal) > 0)
			$result = array_merge((array)$friends, (array)$personal);
		else
			$result = $friends;
		
		return $result;
	}
	
	
	function getByFriendsAll($day, $month, $user_id) {
		
		$this->recursive = 2;
		
		$params = array(
			'fields' => $this->fields,
			'conditions' => array(
					array('or' =>
						array('Event.user_id' => $user_id, 'Friends.user_id' => $user_id)
					),
					'Event.day' => $day, 'Event.month' => $month, 'Event.status' => 3),
					
			'order' => array('year' => 'desc'),
			'joins' => array(
				array(
					'table' => 'users_friends', 					
					'type' => 'LEFT',
					'alias' => 'Friends',
					'conditions' => array(
						'Friends.friend_id = Event.user_id',
						'Friends.user_id = '. $user_id
						)
				)
			)
			//'cache' => 'event_' . $id,
			//'cacheConfig' => 'medium'
		);

		return $this->find('all', $params);
	}
	
	function sortByCategoryYear($events, $friendsEvents) {
		
		foreach($friendsEvents as $tempEvents)
		{
			if($events[0]['Category']['id'] == 36) 
			{
				$result = array_merge((array)$events[0], (array)$tempEvents);
				$events[0] = $result;
			}
			else if($events[0]['Category']['id'] == 37) 
			{
				$result = array_merge((array)$events[1], (array)$tempEvents);
				$events[1] = $result;
			}
			else if($events[0]['Category']['id'] == 38) 
			{
				$result = array_merge((array)$events[2], (array)$tempEvents);
				$events[2] = $result;
			}
			else if($events[0]['Category']['id'] == 39) 
			{
				$result = array_merge((array)$events[3], (array)$tempEvents);
				$events[3] = $result;
			}
		}
		
		return $events;
	}
	
	function category_sort($a, $b)
	{
		if($a['Category']['id'] == $b['Category']['id'])
		{
			return sort($a, $b);
		}
		return ($a['Category']['id'] < $b['Category']['id']) ? -1 : 1;
	}
	
	function sortByDate($events, $friendsEvents) {
		
		$result = array_merge((array)$events, (array)$friendsEvents);
		
		usort($result, array("Event", "sortDate"));
		
		return $result;
	}
	
	function getDataByDate($day, $month) {
		
		$this->recursive = 2;
		
		$params = array(
			'fields' => $this->fields,
			'conditions' => array('Event.day' => $day, 'Event.month' => $month, 'Event.status' => 1),
			'order' => array('category_id' => 'desc', 'year' => 'desc', 'month' => 'desc', 'day' => 'desc')
		);

		return $this->find('all', $params);
	}
	
	function getDataByFriends($day, $month, $user_id) {
		
		$this->recursive = 2;
		
		$params = array(
			'fields' => $this->fields,
			'conditions' => array('Event.day' => $day, 'Event.month' => $month, 
					'or' => array(
						array('Friends.user_id' => $user_id, 'Event.status' => 3 ),
						'Event.status' => 1
					)
				),
			'order' => array('category_id' => 'desc', 'year' => 'desc', 'month' => 'desc', 'day' => 'desc'),
			'joins' => array(
				array(
					'table' => 'users_friends', 					
					'type' => 'LEFT',
					'alias' => 'Friends',
					'conditions' => array(
						'Friends.friend_id = Event.user_id'
						)
				)
			)
		);

		return $this->find('all', $params);
	}
	
	function sortByYear($events, $friendsEvents) {
		
		$result = array_merge((array)$events, (array)$friendsEvents);
		
		usort($result, array("Event", "sort"));
		
		return $result;
	}
	
	function sort($a, $b)
	{
    	if ($a['Event']['year'] == $b['Event']['year']) {
        	return 0;
   		 }
    	return ($a['Event']['year'] > $b['Event']['year']) ? -1 : 1;
	}
	
	function getLive() {
		return $this->find('all', array('conditions' => array('status' => 1)));
	}
	
	function addLink($eventID = null, $linkID = null) {
		
		if($eventID == null || $eventID == 0 || $linkID == null || $linkID == 0)
			return true;
			
		$this->query("
		INSERT INTO events_links (events_links.event_id, events_links.link_id) VALUES ( '" .  $eventID . "', '". $linkID ."')"
		);
		
		return true;
	}
	
	function saveLink($url, $name) {
	
		$url = str_replace(" ", "_", $url);
		$url = "http://en.wikipedia.org/wiki/" . $url;
		
		uses('sanitize');
   		$mrClean = new Sanitize();
		$cleanURL = $mrClean->escape($url);
		
		$results =  $this->query("SELECT * from links WHERE links.url = '" . $cleanURL . "'");
		
		if( count( $results ) != 0)
		{
			return $results[0]['links']['id'];
		}
		
		$data = array(
					'Links' => array(
						'url' => $url,
						'name' => $name
					)
							
				);

		$this->Links->create();
		$this->Links->save($data);
					
		return $this->Links->id;
	}
	
	function getReason($itemID = null) {
		$result = $this->query("SELECT message.message as message FROM message WHERE message.item_id = '" .  $itemID . "' AND message.type = '". $this->itemType . "'");
		
		if(count($result) == 0)
			return "Event does not meet the required criteria to be a valid public event.";
		else
			return $result[0]['message']['message'];
	}
	
	function storeReason($itemID = null, $reason) {
	
		uses('sanitize');
   		$mrClean = new Sanitize();
		$reason = $mrClean->escape($reason);

		$this->query("
		INSERT INTO message (message.item_id, message.type, message.message) VALUES ( '" .  $itemID . "', '". $this->itemType ."', '". $reason ."')"
		);
	}
	
	function deleteReason($itemID = null) {
	
		$result = $this->query("SELECT message.message as message FROM message WHERE message.item_id = '" .  $itemID . "' AND message.type = '". $this->itemType . "'");
		
		if(count($result) == 0)
			return;
		
		$this->query("
		DELETE FROM message WHERE message.item_id = '" .  $itemID . "' AND message.type = '". $this->itemType . "'");
	}
	
	function updateStatus($itemID, $status)
	{
		$this->deleteReason($itemID);
		
		$data = array(
       		'Event' => array(
             	'id'		=> $itemID,
            	'status' 	=> $status
          		)
      	 	);
		
		return $this->save( $data, false, array('status') );
	}
	
	function getSubmitted($userID = null) {	
		
		$this->recursive = 2;
		$params = array(
			'fields' => $this->fields,
			'conditions' => array('Event.user_id' => $userID, 'status' => 1),
			'order' => array('year' => 'desc', 'month' => 'desc', 'day' => 'desc'),
			'limit' => $this->amount
		);
		
		return $params;
	}
	
	function getTimeline($userID = null) {	
		
		$this->recursive = 2;
		$params = array(
			'fields' => $this->fields,
			'conditions' => array('Event.user_id' => $userID, 'status' => 3),
			'order' => array('year' => 'desc', 'month' => 'desc', 'day' => 'desc'),
			'limit' => $this->amount
		);
		
		return $params;
	}
	
	
	function getFavorites($userID = null) {	
		
		$params = array(
			'fields' => $this->fields,
			'conditions' => array('Favorites.user_id' => $userID),
			'order' => array('year' => 'desc', 'month' => 'desc', 'day' => 'desc'),
			'joins' => array(
				array(
					'table' => 'events_users', 					
					'type' => 'INNER',
					'alias' => 'Favorites',
					'conditions' => array(
						'Event.id = Favorites.event_id'
					)
				)
			),
			'limit' => $this->amount
		);
		
		return $params;
	}
	
	function getFavoritesByID($userID = null) {	
		$this->recursive = -1;
		$results =  $this->query("
			SELECT events_users.event_id  from events_users
			WHERE events_users.user_id = " . $userID);
			
		$favorites = array();
		foreach($results as $item)
		{
			$favorites[] = $item['events_users']['event_id'];
		}
		return $favorites;
	}
	
	function addToFavorites($userID = null, $id = null) {	
		
		$favorites =  $this->query("
			SELECT *  from events_users WHERE events_users.event_id = " .  $id . " and events_users.user_id = " . $userID);
			
		if( count( $favorites ) != 0)
			return false;
			
		$this->query("
		INSERT INTO events_users (events_users.event_id, events_users.user_id) VALUES ( '" .  $id . "', '". $userID ."')"
		);
		
		return true;
	}

	function removeFromFavorites($userID = null, $id = null) {	
	
		$favorites =  $this->query("
			SELECT *  from events_users WHERE events_users.event_id = " .  $id . " and events_users.user_id = " . $userID);

		if( count( $favorites ) == 0)
			return false;
			
		$this->query("
			DELETE FROM events_users WHERE events_users.event_id = " .  $id . " AND events_users.user_id = ". $userID
		);
		
		return true;
	}
	
	function getByUserIDStatus($userID, $status = null) {

		if($status == null)
		{
			$conditions = array(
				'fields' => $this->fields,
				'conditions' => array(
					array('or' =>
						array('status' => 1, 'status' => 3)
					),
					'user_id' => $userID,
					),
				'order' => array('Event.year DESC', 'Event.month DESC', 'Event.day DESC'),
				'limit' => $this->amount
			);
		}
		else
		{
			$conditions = array(
				'fields' => $this->fields,
				'conditions' => array(
				'user_id' => $userID,
				'status' => $status),
				'order' => array('Event.year DESC', 'Event.month DESC', 'Event.day DESC'),
				'limit' => $this->amount
			);
		}

		return $conditions;
	}	
	
	
	function getByUserID($userID, $status = 1) {

		$conditions = array(
		'fields' => $this->fields,
		'conditions' => array(
			'user_id' => $userID,
			'status' => $status),
		'order' => array('Event.year DESC', 'Event.month DESC', 'Event.day DESC'),
		);
		
		return $this->find('all', $conditions);
	}	
	
	function getNewEvents() {
		$this->recursive = 2;
		
		return array(
		'fields' => $this->fields,
		'conditions' => array(
			'status' => 0),
		'order' => array('Event.year DESC', 'Event.month DESC', 'Event.day DESC'),
		);
	}
	
	function deleteLinks($itemID = null) {
		$this->query("
		DELETE FROM events_links WHERE events_links.event_id = '" .  $itemID . "'");
	}
	
	function getBySearch($searchText, $count = false) {
	
		if( $count )
		{
			return array(
			'fields' => 'Event.id',
			'conditions' => array('or' =>
				array("Event.event LIKE" => "%". $searchText ."%", "Event.name LIKE" => "%". $searchText ."%"),
				'status' => 1),
			'limit' => $this->amount
			);
		}
		else
		{
			return array(
			'fields' => $this->fields,
			'conditions' => array('or' =>
				array("Event.event LIKE" => "%". $searchText ."%", "Event.name LIKE" => "%". $searchText ."%"),
				'status' => 1),
			'order' => array('Event.year DESC', 'Event.month DESC', 'Event.day DESC'),
			'limit' => $this->amount
			);
		}
	}
	
	
	function getByAdvancedSearch($creator = null, $searchText  = null, $categoryID  = 0) {
		$conditions = array();
		$conditions["or"] = array();
		
		if( !empty( $creator ) )
		{
			$conditions["or"][] = array("User.username LIKE" => "%". $creator ."%");
			$conditions["or"][] = array("User.name LIKE" => "%". $creator ."%");
			$conditions["or"][] = array("User.email LIKE" => "%". $creator ."%");
		}
		
		if( !empty( $searchText ) )
		{
			$conditions["or"][] = array("Event.event LIKE" => "%". $searchText ."%");
			$conditions["or"][] = array("Event.name LIKE" => "%". $searchText ."%");
		}
		
		if($categoryID != 0)
		{
			$conditions["category_id"] = $categoryID;
		}
		
		$conditions["status"] = 1;

		return array(
			'fields' => $this->fields,
			'conditions' => $conditions,
			'order' => array('Event.year DESC', 'Event.month DESC', 'Event.day DESC'),
			'limit' => $this->amount
		);
	}
	
	function getYear($year)
	{
		if($year > 0)
		{
			return $year;
		}
		else
		{
			return -$year + " BC";
		}
	}
	
	function getDateString($event)
	{
		return date("l, F jS", mktime(0, 0, 0, $event['month'], $event['day'], $this->getYear($event['year'])));
	}
	
	function getEventString($data)
	{
		$event = $data['Event'];
		$category = $data['Category']['id'];

		if($category == 36)
	 	{
	 		return "On " . date(" F jS", mktime(0, 0, 0, $event['month'], $event['day'], 2010)) . ", " . $this->getYear($event['year']);
	 	}
		else if($category == 37)
		{
	 		return "Born on " . date("F jS", mktime(0, 0, 0, $event['month'], $event['day'], 2010)) . ", " . $this->getYear($event['year']);
	 	}
		else if($category == 38)
		{
	 		return "Dead on " . date("F jS", mktime(0, 0, 0, $event['month'], $event['day'], 2010)) . ", " . $this->getYear($event['year']);
	 	}
		else if($category == 39)
		{
	 		return "On " . date("F jS", mktime(0, 0, 0, $event['month'], $event['day']));
	 
	 	}
	}
	
	function getCategoryName($data)
	{
		$category = $data['Category']['id'];

		if($category == 36)
	 	{
	 		return "Event";
	 	}
		else if($category == 37)
		{
	 		return "Birth";
		}
		else if($category == 38)
		{
	 		return "Death";
	 	}
		else if($category == 39)
		{
	 		return "Holiday";
	 	}
	}
	
}
?>