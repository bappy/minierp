
function publishItem(id, name, link, linkCategory) {

	var action_links = [{ "text": "Check us out!", "href": "http://www.todayhistory.org/"}]; 

	var event = $j("#item_" + id + " .event").html();
	event = event.replace(/<br>/g,'\n');
	event = event.trim();
	event = event.replace(/<\S[^><]*>/g,'');

	var attachment = {
    'name':  name,
    'href': link,
    'description': event,
    'properties' : { 
    	'Other events' : {
			'text' : 'on that day', 
       		'href' : linkCategory
       		}
      }
	};

	FB.Connect.streamPublish('', attachment, null, null, 'Add a personal message');
	return;
};


var TweetAndTrack = {};
TweetAndTrack.open = function(targ, url) {
var callback_name = url.replace(/\W/g, '');
BitlyClient.call('shorten', {
'longUrl': url,
'history': '1'
}, 'BitlyCB.' + callback_name);
return false;
};
 
TweetAndTrack.popResult = function(data) {
// Results are keyed by longUrl, so we need to grab the first one.
for (var r in data.results) {
return data.results[r];
 }
};

function tweetItem(id) {

var event = $j("#item_" + id + " .event").html();
event = event.replace(/<br>/g,'');
event = event.trim();
event = event.replace(/<\S[^><]*>/g,'');

var url = 'http://www.todayhistory.net/events/view/' + id;

var textMessage = event.replace(new RegExp("^(.{0," + 100 + "}\\b).*"), "$1");
var callback_name = url.replace(/\W/g, '');
BitlyCB[callback_name] = function(data) {
var result = TweetAndTrack.popResult(data);
var tweet_url = "http://twitter.com/home?status=" + encodeURIComponent(textMessage+ "... " + result.shortUrl );
window.open(tweet_url);
};
 
BitlyClient.call('shorten', {
'longUrl': url,
'history': '1'
}, 'BitlyCB.' + callback_name);
 
return false;
}

function emailItem(id, name) {
	
	var event = $j("#item_" + id + " .event").html();
	event = event.trim();
	event = event.replace(/<\S[^><]*>/g,'');
	
	var mailSubject = rawurlencode('Today In History - Event');
	var mailBody =  rawurlencode(name + ': ' + event) + '%0D%0A%20--%20%0D%0A'+  rawurlencode('Check out this event: http://www.todayhistory.net/events/view/' + id) + '%0D%0A%0D%0A' + rawurlencode('via Today in History');
		
	location.replace('mailto:?subject=' + mailSubject + '&body=' + mailBody);

}

function showInviteDialog(hostUrlPrefix, excluded) {
    var fbml = "<fb:request-form requirelogin=1 " +
               "action='" + window.location + "' " +
               "method='POST' " +
               "invite='true' " +
               "type='Today In History' " +
               "content=\"todayhistory.net is a great place to learn more about history, culture and current events, you can share events in your life with your friends and make yourself a part of their history. So join me on Today In History and check out some history! <fb:req-choice url='" + hostUrlPrefix + "/_connectWithFacebook?source=facebookInvite' " +
               "label='Join Today In History' />\"> " +
               "<fb:multi-friend-selector " +
               "showborder='false' " +
               "actiontext='Invite your friends to use Today In History.' exclude_ids='" + excluded + "' ></fb:multi-friend-selector> " +
               "</fb:request-form>";
    showFbPopupDialog("Invite your friends to Today In History!", fbml);
}

function showFbPopupDialog(header, fbml) {
    FB.Connect.requireSession(function() {
        FB.Facebook.apiClient.users_getLoggedInUser(function(user) {
            if (user) {
                var dialog = new FB.UI.FBMLPopupDialog(header, fbml);
                dialog.setContentHeight(400);
                dialog.setContentWidth(800);
                dialog.show();
            }
        });
    });
}

String.prototype.trim = function() {
a = this.replace(/^\s+/, '');
return a.replace(/\s+$j/, '');
};



function showPermissionDialog() {
	FB.Connect.showPermissionDialog("email");
}
                        
function inviteConnectUsers() {
	FB.Connect.inviteConnectUsers();
}

function rawurlencode (str) {
 
 	str = (str+'').toString();
 	
 	return encodeURIComponent(str).replace(/!/g, '%21').replace(/'/g, '%27').replace(/\(/g, '%28').replace(/\)/g, '%29').replace(/\*/g, '%2A');
}