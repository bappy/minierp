var $j = jQuery.noConflict();

$j(document).ready(function(){

	var box = $j(".box_center_title").width() + 70;
	
	document.getElementById('bot_title').style.width = box+'px';
	
   	$j(".signin").click(function(e) {          
		e.preventDefault();
		$j("fieldset#signin_menu").toggle();
		$j(".signin").toggleClass("menu-open");
 	});
			
	$j("fieldset#signin_menu").mouseup(function() {
		return false
	});

	$j(".field").focus(function(){
      	 $j(this.parentNode).addClass('focused'); 
	});
	
	$j(".field").blur(function(){
      	$j(this.parentNode).removeClass('focused'); 
	});
	
	
	//skin for select submit
	$j(".bottom_info .left select").select_skin();
	
    setTimeout(function() { $j('#flashMessage').fadeOut(2000); }, 12000);    
    
    setTimeout(function() { $j('.errors').fadeOut(2000); }, 12000);    
	
	
});

	$j(function(){
	
			$j('#add_categories').selectmenu({
			icons: [
				{find: '.events'},
				{find: '.births'},
				{find: '.deaths'},
				{find: '.holidays'}
			]
		});
	});

	function addToggle() {

		if ($j('.add_hover').css('display') == 'none') {
			$j('.add_hover').slideDown();
		} else {
			$j('.add_hover').slideUp();
		}
	}

	function showItems(id)
	{ 
		$j(".hovered_" + id).slideDown("fast");
		
		$j("#expandOptions_" + id).fadeOut("fast");
		
		setTimeout(function() { $j("#hideOptions_" + id).fadeIn("slow"); }, 100);
	}
		
	function hideItems(id)
	{ 
		$j(".hovered_" + id).slideUp("fast");
		
		$j("#hideOptions_" + id).fadeOut("fast");
		
		setTimeout(function() { $j("#expandOptions_" + id).fadeIn("slow"); }, 500);
		
	}

	function handleFavorite(item){


		itemID = item.match(/\d+/);
		results = $j("#" + item).html();

		if( !results.match("error") )
		{
			$j("#addFave_" + itemID).toggle("hidden");
			$j("#removeFave_" + itemID).toggle("hidden");
		}
	} 

	function handleFriend(item){
		itemID = item.match(/\d+/);
		results = $j("#" + item).html();

		if( !results.match("query_error") )
		{
			$j(".add_" + itemID).toggle("hidden");
			$j(".remove_" + itemID).toggle("hidden");
		}
	} 
    