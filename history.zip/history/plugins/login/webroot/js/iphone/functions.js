var iWebkit;if(!iWebkit) { 
	iWebkit=window.onload=function() { 
		iWebkit.checkboxHeight="25";
		iWebkit.radioHeight="25";
		iWebkit.autolistNumVisible=10;
		
		function b() { 
			var d=document.getElementsByTagName("a");
			for(var e=0;e<d.length;e++) { 
				if(d[e].className.match("noeffect")) { } 
				else { 
					d[e].onclick=function() { 
						window.location=this.getAttribute("href");return false} 
					} 
				} 
			} 
		function c() { 
			window.scrollTo(0,0.9)
		} 
		
		iWebkit.popup=function() { 
			window.scrollTo(0,9999); 
			var e=document.getElementById(arguments[0]); 
			var f=e.getElementsByClassName("confirm_screen")[0]; 
			f.className="confirm_screenopen"; 
			var d=document.getElementById("cover"); 
			d.className="cover"; 
			d.style.height=document.height+"px"
		}; 

		iWebkit.closepopup=function() { 
			var e=arguments[0].toElement; 
			var f=false; 
			do { 
				e=e.parentNode; 
				if(e.tagName.toLowerCase()=="div"&&e.className.toLowerCase()=="popup") { 
					f=true; 
					break
				} 
			} 
		
			while(e.parentNode); 
			if(f===false) { 
				return false
			} 

			var g=e.getElementsByClassName("confirm_screenopen")[0]; 
			g.className="confirm_screenclose"; 
			var d=document.getElementById("cover"); 
			d.className="nocover"; 
			d.style.height=0
		}; 
		
		
		function a() { 
			var g=document.getElementsByTagName("ul"); 
			for(var f=0; f<g.length; f++) { 
				var h=g[f]; 
				try {
					if(h.getAttribute("class").search(/(autolist)/)===-1)
					{ continue } 
				}
				catch(err) { }
var d=h.getElementsByTagName("li"); 
if(d.length<=iWebkit.autolistNumVisible) { 
continue} 
h.numitems=d.length; 
h.visibleitems=0; 
var e=h.getElementsByClassName("autolisttext")[0]; 
e.onclick=function(i) { 
var j=this.parentNode; 
j.showItems(j.visibleitems+iWebkit.autolistNumVisible); 
return false} 
; 
h.showItems=function(l) { 
var j=this.getElementsByTagName("li"); 
var m=0; 
for(var k=0; 
k<j.length; 
k++) { 
j[k].className=j[k].className.replace(/hidden/g,""); 
if(k>=l) { 
j[k].className=j[k].className+" hidden"} 
else { 
m+=1} 
} 
this.visibleitems=m; 
e.className=e.className.replace(/hidden/g,""); 
if(m>=(j.length-1)) { 
e.className=e.className+" hidden"} 
} 
; 
h.showItems(iWebkit.autolistNumVisible)} 
} 
iWebkit.init=function() { 
b(); 
c(); 
a(); 
var h=document.getElementsByTagName("input"),j=[],g,i,k; 
for(var f=0; 
f<h.length; 
f++) { 
if(h[f].type==="checkbox"||h[f].type==="radio") { 
j[f]=document.createElement("span"); 
j[f].className=h[f].type; 
if(h[f].checked) { 
if(h[f].type==="checkbox") { 
var e="0 -"+(iWebkit.checkboxHeight*2)+"px"; 
j[f].style.backgroundPosition=e} 
else { 
e="0 -"+(iWebkit.radioHeight*2)+"px"; 
j[f].style.backgroundPosition=e} 
} 
h[f].parentNode.insertBefore(j[f],h[f]); 
h[f].onchange=iWebkit.clear; 
j[f].onmouseup=iWebkit.check; 
document.onmouseup=iWebkit.clear} 
} 
h=document.getElementsByTagName("select"); 
for(f=0; 
f<h.length; 
f++) { 
if(h[f]) { 
i=h[f].getElementsByTagName("option"); 
k=i[0].childNodes[0].nodeValue; 
g=document.createTextNode(k); 
for(var d=0; 
d<i.length; 
d++) { 
if(i[d].selected) { 
g=document.createTextNode(i[d].childNodes[0].nodeValue)} 
} 
j[f]=document.createElement("span"); 
j[f].className="select"; 
j[f].id="select"+h[f].name; 
j[f].appendChild(g); 
h[f].parentNode.insertBefore(j[f],h[f]); 
h[f].onchange=iWebkit.choose} 
} 
} 
; 
iWebkit.pushed=function() { 
var d=this.nextSibling; 
if(d.checked&&d.type==="checkbox") { 
this.style.backgroundPosition="0 -"+iWebkit.checkboxHeight*3+"px"} 
else { 
if(d.checked&&d.type==="radio") { 
this.style.backgroundPosition="0 -"+iWebkit.radioHeight*3+"px"} 
else { 
if(!d.checked&&d.type==="checkbox") { 
this.style.backgroundPosition="0 -"+iWebkit.checkboxHeight+"px"} 
else { 
this.style.backgroundPosition="0 -"+iWebkit.radioHeight+"px"} 
} 
} 
} 
; 
iWebkit.check=function() { 
var f=this.nextSibling; 
if(f.checked&&f.type==="checkbox") { 
this.style.backgroundPosition="0 0"; 
f.checked=false} 
else { 
if(f.type==="checkbox") { 
this.style.backgroundPosition="0 -"+iWebkit.checkboxHeight*2+"px"} 
else { 
this.style.backgroundPosition="0 -"+iWebkit.radioHeight*2+"px"; 
var g=this.nextSibling.name; 
var e=document.getElementsByTagName("input"); 
for(var d=0; 
d<e.length; 
d++) { 
if(e[d].name===g&&e[d]!==this.nextSibling) { 
e[d].previousSibling.style.backgroundPosition="0 0"} 
} 
} 
f.checked=true} 
} 
; 
iWebkit.clear=function() { 
var e=document.getElementsByTagName("input"); 
for(var d=0; 
d<e.length; 
d++) { 
if(e[d].type==="checkbox"&&e[d].checked) { 
e[d].previousSibling.style.backgroundPosition="0 -"+iWebkit.checkboxHeight*2+"px"} 
else { 
if(e[d].type==="checkbox") { 
e[d].previousSibling.style.backgroundPosition="0 0"} 
else { 
if(e[d].type==="radio"&&e[d].checked) { 
e[d].previousSibling.style.backgroundPosition="0 -"+iWebkit.radioHeight*2+"px"} 
else { 
if(e[d].type==="radio") { 
e[d].previousSibling.style.backgroundPosition="0 0"} 
} 
} 
} 
} 
} 
; 
iWebkit.choose=function() { 
var e=this.getElementsByTagName("option"); 
for(var f=0; 
f<e.length; 
f++) { 
if(e[f].selected) { 
document.getElementById("select"+this.name).childNodes[0].nodeValue=e[f].childNodes[0].nodeValue} 
} 
} 
; 
iWebkit.init()} 
} 
; 
