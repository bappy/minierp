	var $j = jQuery.noConflict();

	$j(document).ready(function(){

    	$j(".hoverer").hoverIntent( showRiddle, hideRiddle )

    	setTimeout(function() { $j('#flashMessage').fadeOut(2000); }, 4000);
   
  	});

  	function showRiddle(){ $j(".hovered_" + this.id.match(/\d+/)).fadeIn("slow"); }
	function hideRiddle(){ $j(".hovered_" + this.id.match(/\d+/)).fadeOut("slow"); } 

	function showResults(item){
		new Effect.Appear(item);
		
		setTimeout(function() {
			new Effect.Fade(item);
		}, 5000);
    } 
    
    function handleFavoriteResults(item){
    
    	itemID = item.match(/\d+/);
    
    	results = $j("#" + item).html();

		if( !results.match("error") )
		{
			$j("#addFave_" + itemID).toggle("hidden");
    		$j("#removeFave_" + itemID).toggle("hidden");
		}
    	
		new Effect.Appear(item);

		
		setTimeout(function() {
			new Effect.Fade(item);
		}, 5000);
    } 
    
    /*
  	function fadeout(item){
        new Effect.Opacity(item, {duration:.1, from:1.0, to:0.0});
        new Effect.Appear(item, {duration:.1});
    } */