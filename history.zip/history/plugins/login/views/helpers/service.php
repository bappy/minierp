<?php
   class ServiceHelper extends Helper
   {
   }
?> 