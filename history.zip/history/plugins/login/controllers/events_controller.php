<?php

App::import('Sanitize');
App::import('Helper');

class EventsController extends AppController {

	var $name = 'Events';
	var $helpers = array('Html', 'Form', 'Js', 'Ajax');
	var $components = array('Email'); 
	var	$paginationLimit = 10;
	var $paginate = array('limit' => 10);
	var $pageTitle = ' | ';		


	function beforeFilter()
	{
		parent::beforeFilter();
		
		$this->setDescriptions( $this->action);
		$this->setTitle( $this->action);
		$this->setViewPath( $this->action );
	}
	
	function submitted($id = null) {
		
		if (!$id) {
			$this->Session->setFlash(__('Invalid User', true));
			$this->redirect($this->Helper->url("/"));	
		}
		
		$this->Event->current = "no-cache";
		$this->Event->recursive = 2;
		
		$this->User->recursive = -1;
		$results = $this->User->findById($id);
		
		if (!$results || !$id) {
			$this->Session->setFlash(__('Invalid User', true));
			$this->redirect($this->Helper->url("/"));	
		}
		
		$this->pageTitle = "Submitted Events";
		$userName = ucfirst($results['User']['username']);
	
		$loggedUser = $this->LoggedUser();
		$this->Event->recursive = 2;
		
		if($loggedUser['id'] == $id)
		{
		
			$items =  $this->Event->getByUserID( $id, 2);
 			$rejected = array();
 			foreach($items as $item)
 			{
 				$reason = $this->Event->getReason($item['Event']['id']);
 				$item['Event']['reason'] = $reason;
				$rejected[] = $item;
 			}
 		
 			$this->set( 'rejected', $rejected ); 
 			
 			$items = $this->Event->getByUserID( $id, 0);
 			$this->set( 'waiting', $items ); 
 			
		}
		else
		{
			$this->set( 'waiting', array() ); 
			$this->set( 'rejected', array() ); 
		}
			
		$this->paginate = $this->Event->getByUserIDStatus( $id, 1 );
 		$this->set( 'global', $this->paginate() ); 
 		

		if($results['User']['username'] != "")
			$this->pageTitle = $userName . '\'s Events';
		else
			$this->pageTitle = "Submitted Events";
			
		$this->set('name', $userName); 
	}
	
	function timeline($id = null) {
		
		if (!$id) {
			$this->Session->setFlash(__('Invalid User', true));
			$this->redirect($this->Helper->url("/"));	
		}
		
		$this->User->recursive = -1;
		$results = $this->User->findById($id);
		
		if (!$results || !$id) {
			$this->Session->setFlash(__('Invalid User', true));
			$this->redirect($this->Helper->url("/"));	
		}
		
		$userName = $this->User->getName($results['User']);
		$this->pageTitle = $userName . "'s Timeline";
		
		$loggedUser = $this->LoggedUser();
		$this->Event->recursive = 2;
 		
 		$items =  $this->Event->getByUserID( $id, 3);
 		$this->set( 'private', $items ); 
 		
		$this->set('name', $userName); 
	}
	
	function favorites ($id = null) {	

		if (!$id) {
			$this->Session->setFlash(__('Invalid User', true));
			$this->redirect($this->Helper->url("/"));	
		}
		
		$this->User->recursive = 0;
		$currentUser = $this->User->getByID($id);
		
		$this->Event->recursive = 2;
        $this->paginate = $this->Event->getFavorites( $id );
		$results = $this->paginate();
		
		if ( count($results) == 0)  {
			$this->Session->setFlash(__('User has no favorites', true));
			$this->redirect($this->Helper->url("/"));	
		}
		
		$this->set('items', $results);

		$userName = ucfirst($currentUser['User']['username']);
		$this->pageTitle = $userName . "'s Favorite Events";
		
		$this->set('pageTitle', $this->pageTitle); 
		$this->set('userName', $userName);   
    }

	function view($id = null, $data = null) {
	
		if ( isset($this->params['id']) )
		{
			$id = $this->params['id'];
		}
		
		if (!$id) {
			$this->Session->setFlash(__('Invalid Event', true));
			$this->redirect($this->Helper->url("/"));
		}

		$event =  $this->Event->getByID($id);
		
		$curEvent = $event['Event'];
		$year = $curEvent['year'];
		
		if($year == 0)
			$this->pageTitle = date("F jS", mktime(0, 0, 0, $curEvent['month'], $curEvent['day'], $year));
		else
			$this->pageTitle = date("F jS, Y", mktime(0, 0, 0, $curEvent['month'], $curEvent['day'], $year));
		
		
		$this->set('title_for_layout', $this->pageTitle);
		
		$loggedUser = $this->Session->read('User');
		$this->set('meta_description', $event['Event']['event']);
		
		$this->set('event', $event);
	}
	
	function today()
	{	
		$this->date(date("m"), date("d"), 'events');
		$this->action = "date";
	}
	
	function date($month = null, $day = null, $category = null) {
	
		if(!$day || !$month)
		{
			$this->Session->setFlash(__('Invalid Date', true));
			$this->redirect($this->Helper->url(""));
		}
			
		$items = Cache::read('events_' . $day . '_' . $month . '_' . $category, 'medium');
			
		if ($items == false) {
			$items =  $this->Event->getByDate($day, $month, $category);
			Cache::write('events_' . $day . '_' . $month . '_' . $category, $items, 'medium');
		}

		if($this->isLoggedIn())
		{
			$loggedUser = $this->LoggedUser();
			$friendsEvents = $this->Event->getByFriends($day, $month, $category, $loggedUser['id']);
			
			if( count($friendsEvents > 0) )
				$items = $this->Event->sortByYear($items, $friendsEvents);
		}
		
		$this->pageTitle = date("l, F jS", mktime(0, 0, 0, $month, $day, date("Y")));
		
		
		$this->set('title_for_layout', $this->pageTitle);
		$this->set('meta_description', "Description");
		$this->set('pageDescription', "Description");
		
		$this->set('day', $day);
		$this->set('month', $month);
		$this->set('type', ucfirst($category));
		
		$this->set('items', $items);
	}
    
    
	function search($query = null) {
	
		$conditions = array('limit' => 10);
		$searchText = null;
		
		if( array_key_exists('query', $this->params['url']) )
		{
			$searchText = $this->params['url']['query'];
			$shortSearch = (strlen($searchText) < 3);
		}
		
		if($searchText == null)
		{
			if($query != null)
			{
				$searchText = $query;
				$shortSearch = (strlen($searchText) < 3);
			}
			else
			{
				//$searchText = '';
				$shortSearch = true;
			}
		}	
		
		$this->pageTitle = "Search Events - " . $searchText;
			
		$this->Event->recursive = 2;
		$this->Event->current = "no-cache";

		if($shortSearch)
			$this->set('events', array());
		else
		{
			$this->paginate = $this->Event->getBySearch( $searchText );
       	 	$this->set('events', $this->paginate());
		}
		
		if($shortSearch)
				$this->Session->setFlash('Search query can not be shorter than 3 characters.');
		
		$this->set('searchText',$searchText);
    } 
    
    function advancedSearch($param1 = null, $param2 = null, $param3 = null) {

		$this->Event->recursive = 2;
		$this->Event->current = "no-cache";
		
		if($param1 != null)
			$textSearch = substr($param1, strpos($param1, "=", 0) + 1);
		if($param2 != null)
			$creatorSearch = substr($param2, strpos($param2, "=", 0) + 1);
		if($param3 != null)
			$categorySearch = substr($param3, strpos($param3, "=", 0) + 1);

		if( isSet( $textSearch ) )
		{
			$this->data['Event']['searchText'] = $textSearch;
		}
		
		if( isSet( $creatorSearch ) )
		{
			$this->data['Event']['creator'] = $creatorSearch;
		}
		
		if( isSet( $categorySearch ) )
		{
			$this->data['Event']['category_id'] = $categorySearch;
		}
		
		if($this->data == null)
			$search = false;
		else
		{
			$search = true;
			
			if( !array_key_exists('searchText' , $this->data['Event']) )
			{
				$this->data['Event']['searchText'] = "";
			}
		
			if( !array_key_exists('creator' , $this->data['Event']) )
			{
				$this->data['Event']['creator'] = "";
			}
		
			if( !array_key_exists('category_id' , $this->data['Event']) )
			{
				$this->data['Event']['category_id'] = 0;
			}
		}
		
		if ( !empty($this->data) && $search ) 
		{
			$this->paginate = $this->Event->getByAdvancedSearch($this->data['Event']['creator'], $this->data['Event']['searchText'], $this->data['Event']['category_id']);
       		$results = $this->paginate();

       		$this->set('events', $results);
       		$this->set('data', $this->data);
		}
		else
		{
			$this->set('events', array());
		}
		
		$categories = $this->Event->Category->getCategoriesBasic();
		$this->set(compact('categories'));
    } 
	
	function edit_fields() {
	}
	
	function edit($id = null) {

		$loggedUser = $this->LoggedUser();
		
		if(!$this->ownsItem($id)) {
			$this->Session->setFlash(__('Can not edit that event', true));
			$this->redirect('/');
		}
		
		if(array_key_exists('link_input', $this->params['form']))
			return false;
			
		if (!empty($this->data)) {
			
			if($this->data['Event']['category_id'] == 37 || $this->data['Event']['category_id'] == 38)
     			$this->Event->validationSet = 'User';
     		else if($this->data['Event']['category_id'] == 39)
				$this->Event->validationSet = 'Holiday';
        
        	if( $this->data['Event']['private'] == 1)
				$this->data['Event']['status'] = 3;
			else if($loggedUser['admin'] != 0)
				$this->data['Event']['status'] = 0;
			
			if ($this->Event->save($this->data)) {
				
				$this->Session->setFlash('The Event has been saved', 'default', array('class' => 'success'));
				
				$this->redirect($this->Helper->url(array('action' => 'submitted', $loggedUser['id'])));	
				
			} else {
				$this->Session->setFlash(__('The Event could not be saved. Please, try again.', true));
			}
		}
		
		if (empty($this->data)) {
			$event = $this->Event->getByID($id);
			$this->data = $event;
			$this->data['Event']['category_id'] = $event['Category']['id'];
			
			$this->Session->write('links', $event['Links']);
		}
		
		$this->set('errors', $this->Event->validationErrors);
		$this->set('item_id', $id);
        	
        	
		$categories = $this->Event->Category->getCategoriesBasic();
		$this->set(compact('categories'));
	}
	
	function edit_links($eventID = null) {
	
		$loggedUser = $this->LoggedUser();
		
		
		if (!$eventID) {
			$this->Session->setFlash(__('Invalid Event', true));
			$this->redirect('/');
		}
		
		if(!$this->ownsItem($eventID)) {
			$this->Session->setFlash(__('Can not edit that event', true));
			$this->redirect('/');
		}
		
		$event = $this->Event->getByID($eventID);
		
		$this->set('event', $event['Event']);
		
		$this->set('item_id', $eventID);
		
		$this->Session->write('link_url', 'http://www.todayhistory.net/events/edit_links/' . $eventID); 
    		
  	 	if(array_key_exists('Links', $this->params['form']))
    	{			
			$this->Event->deleteLinks($eventID);
			
			$this->Event->updateStatus($eventID, 0);
			
			$links = $this->Session->read('links');  
			
			foreach($links as $link)
			{
				if(array_key_exists('Link', $link))
					$link = $link['Link'];
					
				$saved = $this->Event->Links->alreadySaved($link['url']);
				if($saved)
				{
					$results['Results'] = "Success";
					$linkID = $saved['id'];
					$this->Event->addLink($eventID, $linkID);
					continue;
				}
				else
				{
					$data = array(
						'Links' => array(
							'url' => utf8_decode($link['url']),
							'name' => utf8_decode($link['name'])
						)				
					);

					$this->Event->Links->create();
					$this->Event->Links->save($data);
    	
					$linkID = $this->Event->Links->id;
					$this->Event->addLink($eventID, $linkID);
				}
			}
			
			$this->Session->setFlash('The Event\'s links have been updated.', 'default', array('class' => 'success'));
			$this->redirect(array('action' => 'submitted', $loggedUser['id']));
		}
		else if(array_key_exists('Cancel', $this->params['form']))
		{
			 $this->Session->write('links', $event['Links']);
		}
		else if(array_key_exists('Back', $this->params['form']))
		{
			$this->redirect(array('action' => 'edit', $eventID));
		}
	}
	
	function admin() {
	
		$loggedUser = $this->LoggedUser();

		if(!$loggedUser['admin']) {
			$this->Session->setFlash(__('You do not have the permission to view this page', true));
			$this->redirect('/');
		}
		
		$this->paginate = $this->Event->getNewEvents();
 		$this->set( 'items', $this->paginate() ); 
 		
		if(!$loggedUser['admin']) {
			$this->Session->setFlash(__('You do not have the permission to view this page', true));
			$this->redirect('/');
		}
		
	}
		
	function approve( $id ) {
	
		$loggedUser = $this->LoggedUser();

		if(!$loggedUser['admin']) {
			$this->redirect('/');
		}
		
		if (!$id) {
			$this->Session->setFlash(__('Invalid Event', true));
			$this->redirect('/');
		}
		
		$event =  $this->Event->getByID($id);

		$notifications = $this->User->getNotifications($event['User']['id']);
		
		if (in_array(1, $notifications)) {
    		$this->sendApprovalEmail($event);
		}	
		
		if (in_array(3, $notifications)) {
			fopen("http://downshiftit.com/services/users/push_notifications/" . $event['User']['id'] . "/" . $event['User']['username'] . "/3", "r");
		}
		
		$this->Event->updateStatus($id, 1);
		$this->redirect('/events/admin');
	}
	
	function reject( $id ) {
	
		$loggedUser = $this->LoggedUser();
		
		$templates = array();
		
		$templates[] = array('type' => 'event_duplicate', 'message' => "Event is far too similar to another event. Look at <a href=\"http://www.todayhistory.net/events/similar_id\">this event</a>.", 'field' => 'similar_event_id');
		$templates[] = array('type' => 'event_private', 'message' => "Event is not general enough to be allowed in the application, consider making it a private event.");
		$templates[] = array('type' => 'event_description', 'message' => "Event is not descriptive enough. Consider adding a who, what, when, etc.");
		
		$templates[] = array('type' => 'links_irrelevant', 'message' => "Submitted links are not relevant, make sure you've verified that the links are valid and about the event.");
		$templates[] = array('type' => 'links_missing', 'message' => "The information in this event can't be verified, consider adding more relevant links, wikipedia links are preffered, but not required.");

		$this->set('templates', $templates);
		
		if(!$loggedUser['admin']) {
			$this->Session->setFlash(__('You do not have the permission to view this page', true));
			$this->redirect('/');
		}
		
		$event = $this->Event->getByID($id);
		$this->set('event', $event);
		
		if (!empty($this->data)) {
		
			$reason = $this->data['Event']['reason'];
			
			$choice = array_keys($this->params['form']);
			
			foreach($templates as $template)
			{
				if($template['type'] == $choice[0])
					$reason = $template['message'];
				
				if(array_key_exists('field', $template))
				{
					$similar_id = $this->data['Event'][$template['field']];
					$similar_id = trim($similar_id);
					$reason = str_replace('similar_id', $similar_id, $reason);
				}

			}

			if( strlen($reason) < 10)
			{
				$this->Session->setFlash(__('Reason is too short.', true));
			}
			else
			{
			
				$notifications = $this->User->getNotifications($event['User']['id']);
		
				if (in_array(2, $notifications)) {
    				$this->sendRejectionEmail($event, $reason);
				}	
				
				if (in_array(4, $notifications)) {
					fopen("http://downshiftit.com/services/users/push_notifications/". $event['User']['id'] ."/" . $event['User']['username'] . "/4", "r");
				}
			
				if($this->Event->updateStatus($id, 2))
					$this->Event->storeReason($id, $reason);
		
				$this->redirect('/events/admin');
			}
		}
		else
		{
			$this->data['Event']['reason'] = "";
			$this->Session->write('links', $event['Links']);
		}
		
		if(array_key_exists('Cancel', $this->params['form']))
		{
			$this->redirect('/events/admin');
		}
		
		$this->set('errors', $this->Event->validationErrors);
		$this->set('item_id', $id );
	}
	
	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for Joke', true));
			$this->redirect(array('action'=>'index'));
		}
		
		if(!$this->ownsJoke($id)) {
			$this->Session->setFlash(__('Can not delete this joke', true));
			$this->redirect('/');
		}
	
		if ($this->Event->del($id)) {
			$this->LowerJokeCount();
			$this->Session->setFlash(__('Joke deleted', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Joke was not deleted', true));
		$this->redirect(array('action' => 'index'));
	}
	
	function addToFavorites($id) {
    	
    	$loggedUser = $this->LoggedUser();

		$results = $this->Event->addToFavorites($loggedUser['id'], $id);

        if ( $this->RequestHandler->isAjax() ) {
        
         	if ( $results ) {
        		 echo '';
         	} else {
           		echo '<span class="hidden">error</span>';
         	}       
			exit;
         }
   	}
            
	function removeFromFavorites($id) {
		
		$loggedUser = $this->LoggedUser();

		$results = $this->Event->removeFromFavorites($loggedUser['id'], $id);

        if ( $this->RequestHandler->isAjax() ) {
        	
        	if ( $results ) {
        		echo '';
         	} else {
           		echo '<span class="hidden">error</span>';
         	}
             exit;
        } 
    }

	//======================================================================
	//Email Functions
	//======================================================================	
	
	function sendApprovalEmail($data) {
	
		$user = $this->User->getByID($data['User']['id']);
		$user = $user['User'];
		
		if( !$this->isValidEmail($user['email']) )
			return;

		$this->Email->reset();  
		$this->Email->sendAs = 'both';
		
       	//send email using the Email component
        $this->Email->to = '"'. $user['username'].'" <' . $user['email'] . '>'; 
        $this->Email->subject = Configure::read('appName') . ' - Event Approval';
        $this->Email->from = Configure::read('appName') . ' <support@downshiftit.com>';
        $this->Email->replyTo = 'noreply@downshiftit.com';
		$this->Email->template = 'event_approval';  
		
		$this->set('user', $user);  
		$this->set('data', $data);  
        
        $result = $this->Email->send();

   		return $result; 
	}
	
	function sendRejectionEmail($data, $message) {
	
		$user = $this->User->getByID($data['User']['id']);
		$user = $user['User'];
		
		if( !$this->isValidEmail($user['email']) )
			return;

		$this->Email->reset();  
		$this->Email->sendAs = 'both';
		
       	//send email using the Email component
        $this->Email->to = '"'. $user['username'].'" <' . $user['email'] . '>'; 
        $this->Email->subject = Configure::read('appName') . ' - Event Rejection';
        $this->Email->from = Configure::read('appName') . ' <support@downshiftit.com>';
		$this->Email->template = 'event_rejection';  
		
		$this->set('user', $user);  
		$this->set('data', $data);  
        $this->set('message', $message);  
        
        $result = $this->Email->send();

   		return $result; 
	}
	
	
	function isValidEmail($email){
		return eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$", $email);
	}
	
	//======================================================================
	//Helper Functions
	//======================================================================	
	
	function ownsItem($id)
	{
		$loggedUser = $this->LoggedUser();
		$event = $this->Event->read(null, $id);

		if(!$loggedUser)	
			return false;
		else
		{
			if($event['Event']['user_id'] == $loggedUser['id'])
				return true;
			else if($loggedUser['admin'] == 1)
				return true;
			else
				return false;
		}
	}
	
	function setDescriptions($action)
	{
		switch ($action) {
			case "favorites":
			case "view":
				return;
			default:
				$meta_description = "www.todayhistory.net is dedicated to sharing world history and personally significant \"historical\" information. Sign up now so you can share the fun of what happened today or any day for that matter";
				$meta_keywords = "happened today in history, events today in history, births today in history, what happend today in history, famous people history, events history, timelines, personal timelines, this day in history, history today";
				break;
		}
		
		$this->set('meta_description', $meta_description);
		$this->set('meta_keywords', $meta_keywords);
	}
	
	function setTitle($action)
	{
		switch ($action) {
			case "favorites":
				return;
			case "iphone_add":
			case "add":
				$pageTitle = "Add a New Event";
				break;
			case "edit":
				$pageTitle = "Editing Event";
				break;
			case "edit_links":
				$pageTitle = "Editing Event Links";
				break;
			case "iphone_edit":
			case "reject":
				$pageTitle = "Reject Event";
				break;
			case "admin":
				$pageTitle = "Administrate Events";
				break;
			case "edit":
				$pageTitle = "Edit Event";
				break;
			case "search":
				return;
				case "advancedSearch":
				$pageTitle = "Advanced Search";
				break;	
			default:
				$pageTitle = "title";
				break;
		}
		
		$this->pageTitle = $pageTitle;
	}
	
	function setViewPath($action)
	{
		if( $this->layout == "iphone")
			$this->viewPath = $this->viewPath . DS . 'iphone';
	}
	
	//======================================================================
	//Service Functions
	//======================================================================
	
	function service_date($month = null, $day = null, $user_id = 0) {

		if(!$day || !$month)
		{
			return;
		}
		
		$results = Cache::read('daily_' . $day . '_' . $month, 'short');
		if($results)
			$items = $results;
		else
		{
			$items =  $this->Event->getDataByDate($day, $month);
			Cache::write('daily_' . $day . '_' . $month, $items, 'short');
		}
			
		if($user_id != 0)
		{
		
			$friendsEvents = $this->Event->getByFriendsAll($day, $month, $user_id);
			
			if( count($friendsEvents > 0) )
				$items = $this->Event->sortByYear($items, $friendsEvents);
		}
		
		$this->setupJSON();
        
		$this->set('results', $items );
	}
	
	function service_date_single($month = null, $day = null, $category = null, $user_id = 0) {
	
		if(!$day || !$month || !$category)
		{
			return;
		}
			
		$items = Cache::read('events_' . $day . '_' . $month . '_' . $category, 'medium');
			
		if ($items == false) {
			$items =  $this->Event->getByDate($day, $month, $category);
			Cache::write('events_' . $day . '_' . $month . '_' . $category, $items, 'medium');
		}

		if($user_id != 0)
		{
			$loggedUser = $this->LoggedUser();
			$friendsEvents = $this->Event->getByFriends($day, $month, $category, $user_id);
			
			if( count($friendsEvents > 0) )
				$items = $this->Event->sortByYear($items, $friendsEvents);
		}
		
		$results['Results'] = $items;
		
		$this->setupJSON();
        
		$this->set('results', $results );
	}
	
	/*
	function service_all() {
	
		$this->Joke->recursive = 0;
		
		$this->viewPath .= '/json';
        $this->layoutPath = 'json';
        $this->action = "output";
		
		$results = $this->Joke->find('all', array('conditions' => array('live' => 1) ) );
		 
        $this->set('results', $results );
        
       	return;
	}	
    */
    function service_handle_fave () {	

		$jsonData = $this->params['form']['json'];
		$jsonData = json_decode( $jsonData , true );
		
		$item_id = $jsonData["item_id"];
		$user_id = $jsonData["user_id"];
		$change = $jsonData["change"];
		
		if($change == "add")
		{
			$results = $this->Event->addToFavorites($user_id, $item_id);
		}
		else if($change == "remove")
		{
			$results = $this->Event->removeFromFavorites($user_id, $item_id);
		}
		else
		{
			return;
		}
		
        $this->viewPath .= '/json';
        $this->layoutPath = 'json';
        $this->action = "output";
        
        $this->set('results', $results);
    }
    
    function service_new_add() {
    	/**/
		$this->setupJSON();
		
		$item_id = 999;
		$user_id = 0;
		$name = "";
		$event = "";
		
		$day = 10;
		$month = 5;
		$year = 5;
		
		$private = 1;
		$category = 38;
		
		$links = "123,1231,1231,2312,312,31,23,123,1,312,312,";
	
		
		
		if($item_id != 0)
		{
			$item = $this->Event->GetByID($item_id);
		 	if($item['User']['id'] != $user_id)
		 		return;
		 	$this->data['Event']['id'] = $item_id;
		}
		
		$this->data['Event']['user_id'] = $user_id;
		$this->data['Event']['name'] = $name;
		$this->data['Event']['event'] = $event;

		$this->data['Event']['day'] = $day;
		$this->data['Event']['month'] = $month;
		$this->data['Event']['year'] = $year;
		
		if($private == 1)
			$this->data['Event']['status'] = 3;
		else
			$this->data['Event']['status'] = 0;
		
		$this->data['Event']['category_id'] = $category;
		
		if($this->data['Event']['category_id'] == 37 || $this->data['Event']['category_id'] == 38)
     		$this->Event->validationSet = 'User';
     	else if($this->data['Event']['category_id'] == 39)
     	{
			$this->Event->validationSet = 'Holiday';
			unset($this->data['Event']['year']);
		}

		if($private == 1)
		{
			$this->data['Event']['status'] = 3;
			
		}
        
		if($item_id != 0)
			$this->data['Event']['id'] = $item_id;
		else
			$this->Event->create();
		
			
		$this->Event->set($this->data);
		//if($this->Event->validates())
		if ($this->Event->save($this->data)) 
		{
			$this->data['Response'] = "Success";
			$results = $this->data;
			
			if($item_id == 0)
				$item_id = $this->Event->id;
		}
		else
		{
			
			$this->data['Response']['valid'] = 0;
			$this->data['Response'] = "Failed";
			$this->data['Errors'] = $this->Event->validationErrors;
			$results = $this->data;
		}
			
		$this->Event->deleteLinks($item_id);
		foreach($links as $link)
		{
			$this->Event->addLink($item_id, $link);
		}

		/*Debugger::dump(  $results['Event']);
		Debugger::dump(  $results['Response']);
		Debugger::dump(  $results['Errors']);*/
		//Debugger::dump( $this->data['Response'] );
        
        $this->set('results', $results);
        
		return;
	}


    function service_add() {
    	/**/
		$this->setupJSON();
		
		$jsonData = $this->params['form']['json'];
		$jsonData = json_decode( $jsonData , true );
		
		$item_id = $jsonData["item_id"];
		$user_id = $jsonData["user_id"];
			
		$name = $jsonData["name"];
		$event = $jsonData["event"];
		
		$day = $jsonData["day"];
		$month = $jsonData["month"];
		$year = $jsonData["year"];
		
		$private = $jsonData["private"];
		$category = $jsonData["category_id"];
		
		$links = $jsonData["links"];
		$links = explode(",", $links);
		
		/* 
		$item_id = 999;
		$user_id = 0;
		$name = "";
		$event = "Bottom Line";
		
		$day = 10;
		$month = 5;
		$year = 5;
		
		$private = 0;
		$category = 38;
		
		//$links = "123,1231,1231,2312,312,31,23,123,1,312,312,";
		*/
		
		if($user_id == 0)
		{
			$this->data['Response']['valid'] = 0;
			$this->data['Response'] = "Failed";
			$errors = array('private' =>  "Private: You need to log in to submit events");
			$this->data['Errors'] = $errors;
			$results = $this->data;
			$this->set('results', $results);
			return;
		}
		
		if($item_id != 0)
		{
			$item = $this->Event->GetByID($item_id);
		 	if($item['User']['id'] != $user_id)
		 		return;
		 	$this->data['Event']['id'] = $item_id;
		}
		
		$this->data['Event']['user_id'] = $user_id;
		$this->data['Event']['name'] = $name;
		$this->data['Event']['event'] = $event;

		$this->data['Event']['day'] = $day;
		$this->data['Event']['month'] = $month;
		$this->data['Event']['year'] = $year;
		
		if($private == 1)
			$this->data['Event']['status'] = 3;
		else
			$this->data['Event']['status'] = 0;
		
		$this->data['Event']['category_id'] = $category;
		
		if($this->data['Event']['category_id'] == 37 || $this->data['Event']['category_id'] == 38)
     		$this->Event->validationSet = 'User';
     	else if($this->data['Event']['category_id'] == 39)
     	{
			$this->Event->validationSet = 'Holiday';
			unset($this->data['Event']['year']);
		}

		if($private == 1)
		{
			$this->data['Event']['status'] = 3;
			
		}
        
		if($item_id != 0)
			$this->data['Event']['id'] = $item_id;
		else
			$this->Event->create();
		
			
		$this->Event->set($this->data);
		//if($this->Event->validates())
		if ($this->Event->save($this->data)) 
		{
			$this->data['Response'] = "Success";
			$results = $this->data;
			
			if($item_id == 0)
				$item_id = $this->Event->id;
		}
		else
		{
			
			$this->data['Response']['valid'] = 0;
			$this->data['Response'] = "Failed";
			$this->data['Errors'] = $this->Event->validationErrors;
			$results = $this->data;
		}
			
		$this->Event->deleteLinks($item_id);
		foreach($links as $link)
		{
			$this->Event->addLink($item_id, $link);
		}

		/*Debugger::dump(  $results['Event']);
		Debugger::dump(  $results['Response']);
		Debugger::dump(  $results['Errors']);*/
		//Debugger::dump( $this->data['Response'] );
        
        $this->set('results', $results);
        
		return;
	}

    
    function service_view($id = null)
    {
    	if (!$id) {
			return;	
		}
    	$this->setupJSON();
		
    	$item = $this->Event->getByID($id);
    	
    	if($item)
    	{
    		$results['Response'] = "Success";
    		$results['Results'] = array();
    		$results['Results'][] = $item;
    		$results['ResultsCount'] = 1;
  		}
  		else
  		{
  			$results['Response'] = "Failure";
  		}
        
    	$this->set('results', $results);
    }
	
	function service_favorites_list ($id = null) {	
		if (!$id) {
			return;
		}
		$this->setupJSON();
		
        $this->Event->recursive = 2; 
        $results = $this->Event->getFavoritesByID( $id );
        
        $this->set('results', $results);
    }
    
	function service_favorites ($id = null) {	
		if (!$id) {
			return;
		}
		$this->setupJSON();

        $this->Event->recursive = 2; 
        $this->paginate = $this->Event->getFavorites( $id );
		$results['Results'] = $this->paginate();
       	$results['ResultsCount']= $this->User->getFaveCount( $id );

        $this->set('results', $results);
    }

	function service_search($searchText = null) {
		$this->setupJSON();
		$shortSearch = (strlen($searchText) < 3);
		$this->Event->current = "no-cache";
		$this->Event->recursive = 2; 
		$results = array();
		
		if($shortSearch)
			$results = array();
		else 
		{
			$this->paginate = $this->Event->getBySearch( $searchText );
			$results['Results'] = $this->paginate();
       	 	$results['ResultsCount']= $this->Event->paginationCount($this->Event->getBySearch( $searchText, true));
   		}
        
        $this->set('results', $results);
    }
  
    function service_submitted($id = null) {
		if (!$id) {
			return;	
		}
		$this->setupJSON();
		
		$this->Event->current = "no-cache";
		$this->paginate = $this->Event->getSubmitted($id);
		$results['Results'] = $this->paginate();
       	$results['ResultsCount']= $this->Event->find('count', array('conditions' => array('user_id' => $id, 'status' => 1)));

		$this->set('results', $results );
	}
    
    function service_waiting($id = null) {
		if (!$id) {
			return;	
		}
		$this->setupJSON();
		
		$this->Event->current = "no-cache";
		$this->Event->recursive = 2; 
       	
       	$waiting = $this->Event->getByUserID( $id, 0);
       	$results['Results'] = $waiting;
		$results['ResultsCount']= count($waiting);

		$this->set('results', $results );
	}
	
	function service_timeline($id = null) {
		if (!$id) {
			return;	
		}
		
		$this->setupJSON();
		
		$this->Event->current = "no-cache";
		$this->paginate = $this->Event->getTimeline($id);
		$results['Results'] = $this->paginate();
       	$results['ResultsCount']= $this->Event->find('count', array('conditions' => array('user_id' => $id, 'status' => 3)));


		$this->set('results', $results );
	}
	
	function service_rejected($id = null) {
		if (!$id) {
			return;	
		}
		
		$this->setupJSON();
		
		$this->Event->current = "no-cache";
		$this->Event->recursive = 2;
		$items =  $this->Event->getByUserID( $id, 2);
		$rejected = array();
		
 		foreach($items as $item)
 		{
 			$reason = $this->Event->getReason($item['Event']['id']);
 			$item['Event']['reason'] = $reason;
			$rejected[] = $item;
 		}

		$results['Results'] = $rejected ;
       	$results['ResultsCount']= $this->Event->find('count', array('conditions' => array('user_id' => $id, 'status' => 2)));

		$this->set('results', $results );
	}
	
	/*
	function service_owner_submitted($id = null) {
		
		if (!$id) {
			return;
		}

		$this->Joke->current = "no-cache";

		if( $this->params['named']['page'] == 1)
			$jokes = $this->Joke->getHiddenByID($id);
		else
			$jokes = array();
			
		$paginator = $this->paginate('Joke', array('user_id' => $id, 'live' => 1));
		
		$results['Submitted'] = $paginator;
		$results['Hidden'] = $jokes ;
		$results['SubmittedAmount'] = $this->Joke->find('count', array('conditions' => array('user_id' => $id, 'live' => 1)));
	
		//return;
		
		$this->viewPath .= '/json';
        $this->layoutPath = 'json';
        $this->action = "output";

		$this->set('results', $results );
	}*/
	
}	
?>