<?php 
/**
 * Controller for the CakePHP AJAX star rating plugin.
 * 
 * 
 * Copyright (c) 2009 Michael Schneidt
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * 
 * 
 * @author Michael Schneidt (michael.schneidt@arcor.de)
 * @link http://bakery.cakephp.org/articles/view/ajax-star-rating-plugin-1
 * @version 2.0
 */
class RatingsController extends RatingAppController {
  /**
   * (non-PHPdoc)
   * @see cake/libs/controller/Controller#beforeFilter()
   */
  function beforeFilter() {
    // look for config param
    if (isset($this->params['url']['config'])) {
      $config = $this->params['url']['config'];
    } else {
      $options = json_decode(base64_decode($this->params['pass'][2]), true);
      $config = $options['config'];  
    }
    
    // load config    
    if (Configure::load($config) === false && Configure::read('Rating.showHelp')) {
      echo 'Error: The '.$config.'.php was not found in your app/config directory. You can copy it from rating/config/plugin.rating.php';
      exit;
    }
    
    // store and retrieve the guest id to and from session and cookie
    if (Configure::read('Rating.guest') && !$this->Session->check(Configure::read('Rating.sessionUserId'))) {      
      if (!$this->Session->check('Rating.guest_id') 
          && !$this->Cookie->read('Rating.guest_id')) {
        App::import('Core', 'String');
        $uuid = String::uuid();

        $this->Session->write('Rating.guest_id', $uuid);
        $this->Cookie->write('Rating.guest_id', $uuid, false, Configure::read('Rating.guestDuration'));
      } else if (Configure::read('Rating.guest') 
                 && $this->Cookie->read('Rating.guest_id')) {
        $this->Session->write('Rating.guest_id', $this->Cookie->read('Rating.guest_id'));
      }
    }
  }
  
  /**
   * Renders the content for the rating element.
   *
   * @param string $model Name of the model
   * @param integer $id Id of the model
   * @param string $options JSON encoded options or array
   */
  function view($model, $id, $options) {
    $this->layout = null;
    
    $userRating = null;
    $avgRating = null;
    $votes = null;
    $modelInstance = ClassRegistry::init($model);
    $optionsData = json_decode(base64_decode($options), true);
    
    $name = $optionsData['name'];
    $config = $optionsData['config'];    
    
    // check if user id exists in session
    if (Configure::read('Rating.showHelp') 
        && !Configure::read('Rating.guest') 
        && (!$this->Session->check(Configure::read('Rating.sessionUserId')) 
            || !$this->Session->read(Configure::read('Rating.sessionUserId')) > 0)) {
      echo 'Warning: No valid user id was found at "'.Configure::read('Rating.sessionUserId').'" in the session.';
    }
    
    // check if model id exists
    $modelInstance->id = $id;
    
    if (Configure::read('Rating.showHelp') && !$modelInstance->exists(true)) {
      echo 'Error: The model_id "'.$id.'" of "'.$model.'" does not exist.';
    }
    
    // choose between user id and guest id
    /*
    if ($this->Session->read(Configure::read('Rating.sessionUserId') 
        && (Configure::read('Rating.guest')
        && $this->Session->read('Rating.guest_id')))) {
      $userId = $this->Session->read('Rating.guest_id');
    } else {
      $userId = $this->Session->read(Configure::read('Rating.sessionUserId'));
    }*/
    $userId = $this->Session->read('Rating.guest_id');

    if (!empty($userId)) {
      $userRating = $this->Rating->field('rating',
                                         array('model' => $model, 
                                               'model_id' => $id, 
                                               'user_id' => $userId,
                                               'name' => $name));
    }

    if (empty($userRating)) {
      $userRating = 0;
    }
    
    // retrieve rating values from model or calculate them
    if (Configure::read('Rating.saveToModel')) {
      if (Configure::read('Rating.showHelp') 
          && !$modelInstance->hasField(Configure::read('Rating.modelAverageField'))) {
        echo 'Error: The average field "'.Configure::read('Rating.modelAverageField').'" in the model "'.$model.'" does not exist.';
      }
      
      if (Configure::read('Rating.showHelp') 
          && !$modelInstance->hasField(Configure::read('Rating.modelVotesField'))) {
        echo 'Error: The votes field "'.Configure::read('Rating.modelVotesField').'" in the model "'.$model.'" does not exist.';
      }
      
      $values = $modelInstance->find(array($modelInstance->primaryKey => $id),
                                    array(Configure::read('Rating.modelAverageField'), Configure::read('Rating.modelVotesField')),
                                    null,
                                    false);
      
      $avgRating = $values[$modelInstance->name][Configure::read('Rating.modelAverageField')];//$modelInstance->field(Configure::read('Rating.modelAverageField'), array($model.'.'.$modelInstance->primaryKey => $id));
      $votes = $values[$modelInstance->name][Configure::read('Rating.modelVotesField')];
    } else {
      $values = $this->Rating->find(array('model' => $model,
                                          'model_id' => $id,
                                          'name' => $name),
                                    array('AVG(Rating.rating)', 'COUNT(*)'));

      $avgRating = round($values[0]['AVG(`Rating`.`rating`)'], 1);
      $votes = $values[0]['COUNT(*)'];
    }
    
    if (empty($votes)) {
      $votes = 0;
    }
    
    if ($avgRating && !strpos($avgRating, '.')) {
      $avgRating = $avgRating.'.0';
    } else if (!$avgRating) {
      $avgRating = '0.0';
    }

    $this->set('id', $id);
    $this->set('model', $model);
    $this->set('options', $optionsData);
    $this->set('data', array('%VOTES%' => $votes.' '.__n('vote', 'votes', $votes, true), 
                             '%RATING%' => $userRating, 
                             '%AVG%' => $avgRating,
                             '%MAX%' => Configure::read('Rating.maxRating')));
    $this->render('view');
  }
  
  /**
   * Saves the user selected rating value. Depending on the plugin 
   * configuration, it also updates or deletes the rating.
   *
   * @param string $model Name of the model
   * @param integer $id Id of the model
   * @param integer $value User rating value
   */
  function save($model, $id, $value) {
    $this->layout = null;
    $saved = false;
    $modelInstance = ClassRegistry::init($model);

    $name = $this->params['url']['name'];
    $config = $this->params['url']['config'];
    
    // check if model id exists
    $modelInstance->id = $id;
    
    if (!$modelInstance->exists(true)) {
      $this->view($model, $id, base64_encode(json_encode(array('name' => $name, 'config' => $config))));
      
      return;
    }
    
    // choose between user and guest id
    if (Configure::read('Rating.guest') && $this->Session->read('Rating.guest_id')) {
      $userId = $this->Session->read('Rating.guest_id');
    } else {
      $userId = $this->Session->read(Configure::read('Rating.sessionUserId'));
    }
    
    // check if a rating already exists 
    $userRating = $this->Rating->find(array('model' => $model, 
                                            'model_id' => $id, 
                                            'user_id' => $userId,
                                            'name' => $name));
    
    // save, update or delete rating
    if (!empty($userRating) && Configure::read('Rating.allowChange')) {
      $this->Rating->id = $userRating['Rating']['id'];
      
      if ($userRating['Rating']['rating'] == $value && Configure::read('Rating.allowDelete')) {
        $this->Rating->del($userRating['Rating']['id']);
        $saved = true;
      } else {
        $saved = $this->Rating->saveField('rating', $value);
      }
    } else if (empty($userRating) && $userId) {
      $this->data['Rating']['rating'] = $value;
      $this->data['Rating']['model'] = $model;
      $this->data['Rating']['model_id'] = $id;
      $this->data['Rating']['user_id'] = $userId;
      $this->data['Rating']['name'] = $name;
      
      $this->Rating->create();
      $saved = $this->Rating->save($this->data);
    }
    
    // save rating values to model
    if ($saved && Configure::read('Rating.saveToModel')) {
      if (!$modelInstance->hasField(Configure::read('Rating.modelAverageField')) 
          && !$modelInstance->hasField(Configure::read('Rating.modelVotesField'))) {
        $this->view($model, $id, base64_encode(json_encode(array('name' => $name, 'config' => $config))));
        
        return;
      }
      
      $values = $this->Rating->find(array('model' => $model,
                                          'model_id' => $id,
                                          'name' => $name),
                                    array('AVG(Rating.rating)', 'COUNT(*)'));

      $avgRating = round($values[0]['AVG(`Rating`.`rating`)'], 1);
      $votes = $values[0]['COUNT(*)'];
      
      if ($avgRating && !strpos($avgRating, '.')) {
        $avgRating = $avgRating.'.0';
      } else if (!$avgRating) {
        $avgRating = '0.0';
      }

      if (empty($votes)) {
        $votes = '0';
      }
      
      $modelInstance->id = $id;
      
      if ($modelInstance->exists()) {
        $modelInstance->saveField(Configure::read('Rating.modelAverageField'), $avgRating);
        $modelInstance->saveField(Configure::read('Rating.modelVotesField'), $votes);
      }
    }
    
    $this->view($model, $id, base64_encode(json_encode(array('name' => $name, 'config' => $config))));
    $this->autoRender = false;
  }
}
?> 