
<?php
class ServiceComponent extends Object {

}
?> 