<?php

App::import('Vendor', 'openinviter', array('file' => 'OpenInviter'.DS.'openinviter.php'));
       
       
$inviter = new OpenInviter();
$oi_services=$inviter->getPlugins();
       
       
$inviter->startPlugin('google'); // supply a file name with ought .php in the parameter. you will fine the files in the "vendors/openinviter/plugins/" In the Plugins you will find all the files which communicate with the respected services to fatch data. you will pass google, yahoo etc.

// it will return error if any
$internal=$inviter->getInternalError();


// this is use for login in to services just like gmail.com account 1st. parameter take login id and 2nd. parameter takes password
$inviter->login('xpharsh','swardfish');

// this will return the array which contain all the email address from the account you want to fetch.
$contacts = $inviter->getMyContacts();

?>