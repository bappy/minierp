<?php
/**
* Facebook Component
* @author Matt Savarino
* @license MIT
* @version 0.1
*/
$GLOBALS['facebook_config']['debug'] = NULL;

class FacebookComponent extends Object
{
    var $api_key = "fafb0cc1acb3ccfe13205be674056800";
    var $secret = "cd1fbbc49216aa8b6cc0d82911fa2fa6";
    var $facebook = null;
    
    function initialize()
    {
    
    	App::import('Vendor', 'facebook');
       	
       	$this->facebook = new Facebook($this->api_key, $this->secret);
       	//Debugger::dump( $this->facebook->get_loggedin_user() );
    }
    
    function GetUser()
    {
    	//Debugger::dump( $this->facebook->get_canvas_user() );
    	//Debugger::dump( $this->facebook->get_loggedin_user() );
    	
    	$authorized = true;
    	if (!$user = $this->facebook->get_loggedin_user()) {
        	$authorized = false;
        	if (!$user = $this->facebook->get_canvas_user()) {
            	$authorized = false;
        	}
        }
     
        return $user;
    }
    
    function getFriends($loggedUser)
    {    		
    	if(!$loggedUser)
    		return null;
    	
    	$fb_id = $this->GetUser();
    	
      	if(!$fb_id)
       		return null;
    	
    	$friends = $this->facebook->api_client->friends_get();
		
    	$friendData = array();

    	if( !is_array($friends) )
    		return null;
    	
    	foreach($friends as $friend)
    	{
    		
    		$userInfo = array('name, username, is_app_user');
    		
    		try {
				$userInfo = $this->facebook->api_client->users_getInfo($friend, $userInfo);
    		} 
			catch (Exception $ex) {
				continue;
			}
	
    		if( !is_array($userInfo) )
    			continue;

    		if($userInfo[0]['is_app_user'] == 1)
    		{
    			$user = new User();
    			$currentFriend = $user->getByFBID($friend);
    			
    			$friendData[] = $currentFriend['User']['id'];
    		}
    	}
    	
    	if( count($friendData) > 0 )
    		return $friendData;   	
    	else
    		return null;
    }
    
    function shouldClearCookie($loggedUser, $inFacebookApp)
    {

    	$fb_id = $this->facebook->get_loggedin_user();
    	
    	if($fb_id)
    	{
   			try {
				$user = $this->facebook->api_client->fql_query('SELECT first_name FROM user WHERE uid = ' . $fb_id);
			} 
			catch (Exception $ex) {
				return true;
			}
			return false;
		}	 
		
    	if($loggedUser && $loggedUser['fbid'] != 0)
    	{
    		if($fb_id)
    		{
    			if($fb_id != $loggedUser['fbid'])
    			{
    				return true;
    			}
			}
			else
			{
				if($loggedUser['fbid'] && !$inFacebookApp)
				{
					return true;
				}
			}
		}
    	return false;
	}
	
	function getUserData($fb_id)
	{
		//Debugger::dump($fb_id);
		$userInfo = array('name, username, birthday_date, about_me, sex, website');
        $userInfo = $this->facebook->api_client->users_getInfo($fb_id,$userInfo);
		
		if($userInfo[0]['username'] == "")
		{
			$userInfo[0]['username'] = $userInfo[0]['name'];
		}
			
		if($userInfo[0]['sex'] == "male")
		{
			$userInfo[0]['gender'] = 1;
		}
		else if($userInfo[0]['sex'] == "female")
		{
			$userInfo[0]['gender'] = 2;
		}
		else
		{
			$userInfo[0]['gender'] = 0;
		}
		
		$userInfo[0]['url'] = $userInfo[0]['website'];
		
		return $userInfo[0];	
	}
	
	function getFacebookURLs($fb_id)
	{

		$userInfo = array('pic_square, pic_big');
        $userInfo = $this->facebook->api_client->users_getInfo($fb_id,$userInfo);

		if(is_array($userInfo))
			return $userInfo[0];	
		else
			return false;
	}
	
		
	function checkSession()
	{
		$iframeSessionKeyName = $this->api_key. '_session_key';
		$sessionKey = null;
		
		if (isset($_REQUEST[$iframeSessionKeyName])) {
   			$sessionKey = $_REQUEST[$iframeSessionKeyName];
		}
		else if (isset($_REQUEST['fb_sig_session_key'])) {
   			$sessionKey = $_REQUEST['fb_sig_session_key'];
		}
	
		if( isset($sessionKey) )
		{
			setcookie("FBSessionKey", $sessionKey);
		}
		
		if (!empty( $_COOKIE['FBSessionKey']) && !isset($this->facebook->api_client->session_key) ) 
		{
			$this->facebook->api_client->session_key = $_COOKIE['FBSessionKey'];
		}
			
	}
	
	function clearCookie()
	{
		$this->facebook->clear_cookie_state();
	}
	
	    function hasPermission($permission)
    {
    	$userFBID = $this->GetUser();
    	if (!$userFBID)
    		return false;
    		
    	try {
			  return $this->facebook->api_client->users_hasAppPermission("publish_stream");	
		} 
		catch (Exception $ex) {
			return false;
		}

    }
    
    function isAppUser()
    {
    	$userFBID = $this->GetUser();
    	
   		$userInfo = array('is_app_user');
    	
   		try {
			$userInfo = $this->facebook->api_client->users_getInfo($userFBID, $userInfo);
    	 } 
		catch (Exception $ex) {
			return false;
		 }
    	
    	if (!$userInfo)
    		return false;
    		
    	if($userInfo[0]['is_app_user'] == 1)
    		return true;
    	else
    		return false;
    }
	
}
?>