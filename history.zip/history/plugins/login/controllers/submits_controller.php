<?php  

class SubmitsController extends AppController {
    var $components = array('Wizard');
    var $uses = array('Event', 'Link');
    var $helpers = array('Html', 'Form', 'Ajax', 'Time', 'Complete');
    
    function beforeFilter() {
    	parent::beforeFilter();
        $this->Wizard->steps = array('event', 'links', 'review');
    } 
    
    function wizard($step = null) {
    	$this->step( $step );
    	$this->action = 'step';
    }
    
    function step($step = null) {
    	
    	$this->pre_load( $step );
    	     
        $this->Wizard->process($step);	
    }
    
    function pre_load($step = null)
    {	
    	if($step == "event")
    	{
           	$categories = $this->Event->Category->getCategoriesBasic();
			$this->set(compact('categories'));
    	}
    	else if($step == "links")
    	{
    		$this->Session->write('link_url', 'http://www.todayhistory.net/submits/step/links'); 
    		
    		$wizardData = $this->Wizard->read();
    		$this->set('event', $wizardData['event']['Event']);
    	
    		$links = $this->Session->read('links'); 
    		if( count($links) > 0) {
    			$this->data['Links'] = $links;
    		}
    		else
    			$this->data['Links'] = array();
    	}
    	
    	else if($step == 'review')
    	{
    		$wizardData = $this->Wizard->read();
    		$this->data = $wizardData;

    		$this->set('category_name', $this->Event->Category->getNameForID($this->data['event']['Event']['category_id']));
    	}
    	
    }
    
    function _processEvent() {

		if ( !$this->RequestHandler->isPost() ) {
			return false;
    	}

		$this->Event->set($this->data);
		
		if($this->data['Event']['category_id'] == 37 || $this->data['Event']['category_id'] == 38)
     		$this->Event->validationSet = 'User';
     	else if($this->data['Event']['category_id'] == 39)
     	{
			$this->Event->validationSet = 'Holiday';
			unset($this->data['Event']['year']);
		}

		if($this->data['Event']['private'] == 1)
		{
			$this->data['Event']['status'] = 3;
			
		}

		$validates = $this->Event->validates();
        if($validates) {
            return true;
        }
        
    	$this->Event->validates();
    	
        $this->set('errors', $this->Event->validationErrors);
        return false;
    }
    
    function _processLinks() {
    
    	if ( !$this->RequestHandler->isPost() ) {
			return false;
    	}
			
    	$links = $this->Session->read('links'); 
    	
		if(array_key_exists('link_input', $this->params['form']))
			return false;
    	
    	if( count($links) > 0) {
    		$this->data['Links'] = $links;
    		return true;
    	}
    	
    	$wizardData = $this->Wizard->read();
    	$this->data = $wizardData['event'];
    	
    	if(array_key_exists('private', $this->data['Event']))
		{
			$isPrivate = $this->data['Event']['private'];	
		}
		else
		{
			$isPrivate = false;
		}

    	if($isPrivate)
    	{
    		$this->data['Links'] = array();
    		return true;
    	}
    	
    	$this->set('errors', array('Error' => "Public entries needs at least one link refference."));
    	return false;
    }

    function processReview() {
    
    	if ( !$this->RequestHandler->isPost() ) {
			return false;
    	}
    	
    	$wizardData = $this->Wizard->read();
    	$this->data = $wizardData;
    	
    	$user = $this->loggedUser();
    	
    	//star complete
    	extract($wizardData);
    
    	if($this->isLoggedIn())
		{
			$event['Event']['user_id'] = $user['id'];
		}
		
    	$this->Event->set($event);
						
		$this->Event->create();
		
		if($event['Event']['category_id'] == 37 || $event['Event']['category_id'] == 38)
     		$this->Event->validationSet = 'User';
     	else if($event['Event']['category_id'] == 39)
			$this->Event->validationSet = 'Holiday';
			
		if($this->Event->save($event))
			$eventID = $this->Event->id;
		else
		{
			$this->set('errors', $this->Event->validationErrors);
			return false;
		}
		
		//$this->Event->save($event);			
		//$eventID = $this->Event->id;
		
		$links = $links['Links'];
		
		foreach($links as $link)
		{
			$link = $link['Link'];
				
			$saved = $this->Event->Links->alreadySaved($link['url']);
			if($saved)
			{
				$linkID = $saved['id'];
				$this->Event->addLink($eventID, $linkID);
			}
			else
			{
				$data = array(
					'Links' => array(
						'url' => utf8_decode($link['url']),
						'name' => utf8_decode($link['name'])
					)				
				);


				$this->Event->Links->create();
				$this->Event->Links->save($data);
    	
				$linkID = $this->Event->Links->id;
				$this->Event->addLink($eventID, $linkID);
			}
		}
		
		$this->Wizard->resetWizard();
		$this->Session->write('links', array()); 
		
		if($this->isLoggedIn())
		{
			$this->Session->setFlash('You Event has been Submitted, Thank You.', 'default', array('class' => 'success'));
			$this->redirect('/events/submitted/' . $user['id']);
		}
		else
		{
			$this->redirect('/');
		}
		
        return true;
    }
 
    function afterComplete() {
    } 
    
} 

?>