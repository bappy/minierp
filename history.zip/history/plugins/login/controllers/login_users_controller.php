<?php
	App::import('Sanitize');

	class LoginUsersController extends LoginAppController
	{
    	var $name = 'LoginUsers';

    	var $uses =array('login.LoginUser');
		var $helpers = array('Html', 'Form');
		var $components = array('Email', 'Tickets', 'Attachment','Auth');

		function beforeFilter()
		{
            $this->Auth->allow('*');
            parent::beforeFilter();

			$this->setDescriptions( $this->action);
			$this->setTitle( $this->action);
			$this->setViewPath( $this->action );
		}

	
    	function login()
   		{
   			$this->pageTitle = 'Login'; 
   			$this->logout(false);

    		if(!empty($this->data))
        	{

							
            	if(($user = $this->LoginUser->validateLogin($this->data['LoginUsers'])) == true)
           		{


           			//$this->LoginUser->findfirst(array("conditions"=>array("username")))

                   $data=$this->LoginUser->find('all', array('conditions' => array('LoginUser.Username' =>$this->data["LoginUsers"]["username"])));
                       $this->Auth->login($data[0]["LoginUser"]);

                       $this->Session->setFlash('You\'ve successfully logged in.', 'default', array('class' => 'success'));
                       $this->redirect(array('plugin' => false, 'controller' => 'HeadlineQuotes', 'action' => 'add'));

                	}
           		else
           		{

           			$this->Session->setFlash('Wrong username and password combination.');

           		}
            	
        	}

           // else if($this->isLoggedIn()&&(empty($this->data)))
             //      ;


           }
		
		function logout($flash=true)
		{
			$this->AuthExtension->logout();
        	$this->Auth->logout(); 
			$this->logoutUser();
		    $this->Session->destroy();
            if($flash)
        	$this->Session->setFlash('You\'ve successfully logged out.', 'default', array('class' => 'success'));

		}
		
		function invite() { 
		
			App::import('Vendor', 'openinviter', array('file' => '../../OpenInviter'.DS.'openinviter.php'));
       
			$inviter = new OpenInviter();
			
			$inviter=new OpenInviter();
			$oi_services=$inviter->getPlugins();

			$useless = array('abv', 'aol', 'linkedin', 'apropo', 'atlas', 'care2', 'aussiemail', 'azet', 'bigstring', 
				'bordermail', 'canoe', 'are2', 'clevergo', 'doramail', 'evite', 'fm5', 'freemail',
				'graffiti', 'inbox', 'inet', 'interia', 'katamail', 'kids', 'libero', 'meta', 
				'mynet', 'netaddress', 'nz11', 'operamail', 'pochta', 'popstarmail', 'rambler', 'rediff', 
				'sapo', 'techemail', 'terra', 'uk2', 'virgilio', 'walla', 'web_de', 'wpl', 
				'yandex', 'zapak', 'india', 'indiatimes', 'mail_in', 'mail_ru', 'o2', 'fastmail',
				'hushmail', 'mail2world', 'gmx', 'lycos', 'mail_com', 'gmx_net', 'gawab');

			foreach($useless as $uselessEntry)
			{
				unset( $oi_services['email'][$uselessEntry] );
			}

			unset( $oi_services['social'] );


			$this->set('inviter', $inviter);
       
			if (isset($_POST['provider_box'])) 
			{
				if (isset($oi_services['email'][$_POST['provider_box']])) $plugType='email';
				elseif (isset($oi_services['social'][$_POST['provider_box']])) $plugType='social';
				else $plugType='';
			}
			else $plugType = '';

			$this->set('oi_services', $oi_services);
			
			$ers = array();
			$loggedUser = $this->LoggedUser();
			
			if ($this->RequestHandler->isPost() && ( array_key_exists('email_box',$_POST) || array_key_exists('friend_email',$_POST) ) ) {

				if(!empty($_POST['send_single']))
				{
					$ers2 = array();
					
					if (empty($_POST['friend_email']))
					{
						$ers2['email']="You need to enter an Email.";
					}
					else if(!$this->isValidEmail($_POST['friend_email']))
					{
						$ers2['email']="You need to enter a valid Email.";
					}
					if (empty($_POST['friend_message']))
						$ers2['password']="You need to enter a Message.";
					
						
					$this->set('ers2', $ers2);
					
					$data = array();
					
					$data['email'] = $_POST['friend_email'];
					$data['message'] = $_POST['friend_message'];
					$data['sender'] = $loggedUser;
					
					if(count($ers2) == 0)
					{
						if($this->sendInviteEmail($data))
                		{
                			$this->Session->setFlash('Invite email has been sent.', 'default', array('class' => 'success'));
                			$_POST['friend_email']='';
							$_POST['friend_message']='';
                		}else{
                    		$this->Session->setFlash('Unable to send emails, please try again later.');
                    		$this->log("Was unable to send invite email");
                		}
					}
					
					$_POST['email_box']='';
					$_POST['password_box']='';
					$_POST['provider_box']='';
					$this->set('step', 'get_contacts');
					$this->set('done', false);
			
					return;
					
				}
				
				$contacts = array();
				
				if (!empty($_POST['step'])) $step=$_POST['step'];
				else $step='get_contacts';
				
				if ($step=='get_contacts')
				{
		
					if (empty($_POST['email_box']))
						$ers['email']="You need to enter an Email.";
					if (empty($_POST['password_box']))
						$ers['password']="You need to enter a Password.";
					if (empty($_POST['provider_box']))
						$ers['provider']="You need to choose a provider.";
					if (count($ers)==0)
					{
						$inviter->startPlugin($_POST['provider_box']);
						$internal=$inviter->getInternalError();
						
						if ($internal)
							$ers['inviter']=$internal;
						elseif (!$inviter->login($_POST['email_box'],$_POST['password_box']))
						{
							$internal=$inviter->getInternalError();
							$ers['login']=($internal?$internal:"Login failed. Please check the email and password you have provided.");
						}
						elseif (false===$contacts=$inviter->getMyContacts())
							$ers['contacts']="Unable to get contacts !";
						else
						{
							$import_ok=true;
							$step='setup_invites';
							$_POST['oi_session_id']=$inviter->plugin->getSessionID();
							$_POST['message_box']='';
						}
					}
				}
				elseif ($step=='setup_invites')
				{
					
					if (empty($_POST['provider_box'])) $ers['provider']='Provider missing !';
					else
					{
						$inviter->startPlugin($_POST['provider_box']);
						$internal=$inviter->getInternalError();
						if ($internal) $ers['internal']=$internal;
						else
						{
							if (empty($_POST['email_box']))
								$ers['inviter']='Need to choose some recipients.';
							if (empty($_POST['oi_session_id'])) 
								$ers['session_id']='Email session was lost, login to your email again.';
							if (empty($_POST['message_box']))
								$ers['message_body']='Need to enter a message';
							else
								$_POST['message_box']=strip_tags($_POST['message_box']);
							
							$selected_contacts=array();$contacts=array();
							$message=array('subject'=>$inviter->settings['message_subject'],'body'=>$inviter->settings['message_body'],'attachment'=>"\n\rAttached message: \n\r".$_POST['message_box']);
							if ($inviter->showContacts())
							{
								foreach ($_POST as $key=>$val)
									if (strpos($key,'check_')!==false)
										$selected_contacts[$_POST['email_'.$val]]=$_POST['name_'.$val];
									elseif (strpos($key,'email_')!==false)
									{
										$temp=explode('_',$key);$counter=$temp[1];
										if (is_numeric($temp[1])) $contacts[$val]=$_POST['name_'.$temp[1]];
									}
								if (count($selected_contacts)==0) 
									$ers['contacts']="Need to choose some recipients";
							}
							
							if( count($ers)==0 )
							{
								$step = 'send_invites';
							}
						}
					}
				}
			
				$_POST['friend_email']='';
				$_POST['friend_message']='';
			
				$this->set('contacts', $contacts);
				$this->set('step', $step);
				$done = false;
				if ($step == 'send_invites')
				{
					$failedEmails = "";
					foreach ($selected_contacts as $email=>$name)
					{
						
						$data['email'] = $email;
						//$data['email'] = "manuel.zamora.86@gmail.com";
						$data['message'] = $_POST['message_box'];
						$data['sender'] = $loggedUser;

						$success = $this->sendInviteEmail($data);
						
						if( !$success )
						{
							if( empty($failedEmails) )
							{
								$failedEmails .= $email;
							}
							else
							{
								$failedEmails .= ', '. $email;
							}
						}
						
					}
					
					if( empty($failedEmails) )
					{
						$this->Session->setFlash('Invite emails have been sent.', 'default', array('class' => 'success'));
						$this->redirect("/users/invite");
					}
					else
					{
						$ers['general'] = "There was an error in sending the following emails: " . $failedEmails;
						$this->set('ers', $ers);
						$step = 'setup_invites';
						$this->set('step', $step);
					}
				}
				else
				{
					$this->set('done', false);
					$this->set('ers', $ers);
					return;
				}
				
				$this->set('done', $done);
		}
		else
		{
			$this->set('step', 'get_contacts');
			$_POST['email_box']='';
			$_POST['password_box']='';
			$_POST['provider_box']='';
			$_POST['friend_email']='';
			$_POST['friend_message']='';
			$this->set('done', false);
		}
	}
		
		// creates a ticket and sends an email
    	function reset_password()
    	{
    		$this->log("New Password - User was not saved.");
	 		if (empty($this->data))
	 		{
	 			return;
	 		}
	 		
        	if (!empty($this->data['User']['email']))
        	{
            	$theUser = $this->User->findByEmail($this->data['User']['email']);
            
            	if(is_array($theUser) && is_array($theUser['User']))
            	{
            		if($this->Tickets->isAlreadySent($theUser['User']['email']))
            		{
            			$this->Session->setFlash('Email has already been sent, check your email or wait 24 hours and try again.');
            			return;
            		}
            		
               		$theUser['User']['ticket'] = $this->Tickets->set($theUser['User']['email']);
                
					if($this->sendForgotPasswordEmail($theUser['User']))
                	{
                		$this->Session->setFlash('A recovery email has been sent, check your email.', 'default', array('class' => 'success'));
                	}else{
                    	$this->Session->setFlash('Server error, please try again later.');
                    	$this->log("Was unable to send email");
                	}
            	}else{
                	// no user found for adress
                	$this->Session->setFlash('No user with that email address');
            	}
        	}
        	else{
        		$this->Session->setFlash('Please enter an email address');
        	}
    	}


	// uses the ticket to reset the password for the correct user.
    function new_password($hash = null)
    {
    	
		$this->set('hash',$hash);
		$this->set('errors',null);
		
        if ( $email = $this->Tickets->get($hash) )
       	{
           	$authUser = $this->User->findByEmail($email);
           	if (is_array($authUser))
           	{
               	if (!empty($this->params['data']))
               	{
               		//Debugger::dump(Security::hash(Configure::read('Security.salt') . $this->data['password']));
               		//Debugger::dump($this->Auth->password($this->data['password']));
                		
               		$authUser['User']['password'] = $this->Auth->password($this->data['password']);
               		$authUser['User']['password_confirm'] = $this->data['password_confirm'];
                	
					$this->User->set($authUser);
					
					unset($this->User->validate['email']);
					unset($this->User->validate['username']);
						
					if(!$this->User->validates())
					{	
						unset($this->data['password']);
						unset($this->data['password_confirm']);
        		
						$this->set('errors',$this->User->invalidFields());
						$this->Session->setFlash('Unable to reset your password, sorry. Please try again or contact us.');
						return;
					}
				
				if ($this->User->save($authUser))
                   	{
                       	$this->Session->setFlash('Your new password was saved.', 'default', array('class' => 'success'));   
                       	$this->Tickets->del($hash);
                       	$this->redirect( '/' );
                   	}else{
                       	$this->Session->setFlash('User could not be saved. Please contact us with your issue.');
                       	$this->log("New Password - User was not saved.");
                   	} 
               	}
                	
               	unset($authUser['User']['pass']);
               	$this->params['data'] = $authUser;
               	$this->render();
               	return;
           	}
        }
        $this->Session->setFlash('Improper/expired link, check your email again.');    
        $this->redirect('login', null, true);
    }
    
    function register() {
   
   		$this->pageTitle = 'Register'; 
   			
   		//if($this->isLoggedIn())
   		//	$this->logout();
            
        /*if (!empty($this->data)) {
           debug($this->data);
        	
        	$this->LoginUser->set($this->data["LoginUsers"]);
			
			if(!$this->LoginUser->validates())
			{
			    $this->data['LoginUsers']['password'] = "";
        		$this->data['LoginUsers']['password_confirm'] = "";
       			return;
			}

            $this->LoginUser->create();
            if ($this->LoginUser->save($this->data["LoginUsers"])) {

                $data=$this->LoginUser->find('all', array('conditions' => array('LoginUser.Username' =>$this->data["LoginUsers"]["username"])));
                debug($this->data);
                $this->Auth->login($data[0]["LoginUser"]);
                
                $this->sendConfirmationEmail($this->data['User']);
                $this->Session->setFlash('Thank you for registering, a confirmation email has been sent.', 'default', array('class' => 'success'));
                $this->redirect('/');
            } else {
                $this->Session->setFlash('Can not register, sorry. Please try again or contact us.');
            }
        }
   
        $this->data['User']['password'] = "";
        $this->data['User']['password_confirm'] = "";
        */

        $this->LoginUser->set($this->data["LoginUsers"]);
        if (!empty($this->data)&&($this->LoginUser->validates())) {
            $this->User->create();
            $this->data['LoginUsers']["password"]=$this->Auth->password($this->data['LoginUsers']["password"]);
            if($this->User->save($this->data["LoginUsers"]))
            {
                $data=$this->LoginUser->find('all', array('conditions' => array('LoginUser.Username' =>$this->data["LoginUsers"]["username"])));

                if($this->Auth->login($data[0]["LoginUser"]))
                {
                    $this->redirect("/");

                }




        }
    }

    }

	function view($id = null) {
	
		
		if ( isset($this->params['id']) )
		{
			$id = $this->params['id'];
		}
   		
   		
    	$loggedUser = $this->LoggedUser();
    	
    	$this->set('errors', null);
    	
		if (!$id) {

			$this->Session->setFlash(__('No such user.', true));
			$this->redirect($this->Helper->url("/"));
		}
		
		$currentUser = $this->User->getByID($id);
		

		$favoritesCount = $this->User->getFaveCount($id);
		$this->set('favoritesCount', $favoritesCount);
		
		$friendCount = $this->User->getFriendsCount( $id);
		$this->set('friendCount', $friendCount);
		
		$itemCount = $this->User->Events->find('count', array('conditions' => array('user_id' => $id)));
		$this->set('itemCount', $itemCount);
		
		$commentCount = $this->User->Comments->find('count', array('conditions' => array('creator_id' => $id)));
		$this->set('commentCount', $commentCount);
		
		$currentUser = $this->User->getByID($id);
		
		$profilePic = $this->User->getPic($currentUser['User']);
		
		$this->pageTitle = $currentUser['User']['username'] . '\'s Profile'; 
		
	
		if( empty($currentUser['User']['name']) )
			unset($currentUser['User']['name']);

		if($currentUser['User']['birthdate'] != '0000-00-00')
			$currentUser['User']['birthdate'] = date("F j, Y", strtotime($currentUser['User']['birthdate']));
		else
			unset($currentUser['User']['birthdate']);

		if( empty($currentUser['User']['about_me']) )
			unset($currentUser['User']['about_me']);

		$this->set('currentUser', $currentUser);
		$this->set('profilePic', $profilePic);  
	}
	
	function friends($id = null) {
   		
   		if (!$id) {
			$this->Session->setFlash(__('No such user.', true));
			$this->redirect($this->Helper->url("/"));
		}
		
    	$loggedUser = $this->user;
    	
    	if($loggedUser['id'] != $id)
		{
			$this->Session->setFlash(__('You are not this user.', true));
			$this->redirect($this->Helper->url("/"));
		}
		
		$friendResults = $loggedUser['Friends'];
		$this->set('friend_ids', $friendResults);
		
		$friends = array();
		
		foreach($friendResults as $friend)
		{
			$friends[] = $this->User->getByID($friend);
		}
		
		$this->set('friends', $friends);
		
		$this->User->recursive = -1;
    	$currentUser = $this->User->getByID($id);
			
    	$this->pageTitle = $currentUser['User']['username'] . '\'s Friends'; 
    	
    	$this->set('User', $this->User);
    	$this->set('currentUser', $currentUser);
    	
    }
    
	function edit($id = null) {
   		
   		if (!$id) {
			$this->Session->setFlash(__('No such user.', true));
			$this->redirect($this->Helper->url("/"));
		}
		
    	$loggedUser = $this->LoggedUser();
    	
    	if($loggedUser['id'] != $id)
		{
			$this->Session->setFlash(__('You are not this user.', true));
			$this->redirect($this->Helper->url("/"));
		}
		
    	$this->User->recursive = 0;
    	
		$currentUser = $this->User->getByID($id);
		
		$profilePic = $this->User->getPic($currentUser['User']);
		
		$this->pageTitle = $currentUser['User']['username'] . '\'s Profile'; 
		
		$this->set('currentUser', $currentUser);
		$this->set('profilePic', $profilePic);  
		
		if (empty($this->data)) {
			$this->data = $currentUser;
			
			$results = $this->User->getNotifications($id);
	
			foreach($results as $notifications)
			{
				if($notifications == 1)
					$this->data['User']['notification_approval'] = 1;
				if($notifications == 2)
					$this->data['User']['notification_rejection'] = 1;
			}
			
			return;
		}
		
		$this->User->set($this->data);
		
		$fields = array();
		
		if($currentUser['User']['username'] == $this->data['User']['username'])
		{
			unset($this->User->validateEdit['username']);
		}
		else
		{
			$fields[] = 'username';
		}
		
		if($currentUser['User']['name'] != $this->data['User']['name'])
		{
			$fields[] = 'name';
		}
			
		if($currentUser['User']['email'] == $this->data['User']['email'])  
		{
			unset($this->User->validateEdit['email']);
		}
		else if($currentUser['User']['fbid'] != 0 && $this->data['User']['email'] == "")
		{
			unset($this->User->validateEdit['email']);
			$fields[] = 'email';
		}
		else
		{
			$fields[] = 'email';
		}
		
		if($currentUser['User']['about_me'] != $this->data['User']['about_me'])
		{
			$fields[] = 'about_me';
		}

		if($currentUser['User']['url'] != $this->data['User']['url'])
		{
			$fields[] = 'url';
		}
		else
		{
			unset($this->User->validateEdit['url']);
		}
		
		if($currentUser['User']['gender'] != $this->data['User']['gender'])
		{
			$fields[] = 'gender';
		}
		
		if($currentUser['User']['birthdate'] != $this->data['User']['birthdate'])
		{
			$fields[] = 'birthdate';
		}
		
		if(!$this->User->validates())
		{	
			$this->Session->setFlash('Account was not updated. Please, try again or contact us.');
			return;
		}  
		
		if(count($fields) == 0)
		{	
			$this->Session->setFlash('Nothing to update');
			return;
		}  
		
		if ($this->User->save($this->data, false, $fields)) {
			Cache::delete('user_user_' . $id, 'short');
			$this->loginByUserID($this->data['User']['id']);
			$this->Session->setFlash(__('Account has been updated', true), 'default', array('class' => 'success'));
			$this->redirect($this->Helper->url("/users/edit/" . $loggedUser['id']));	
			
		} else {
			$this->Session->setFlash(__('Account was not updated. Please, try again.', true));
		}
		
		$genders = array('unknown' => 0, 'male' => 1, 'female' => 2);
		$this->set(compact('genders'));
	}
	
	function notifications($id = null) {
   		
   		if (!$id) {
			$this->Session->setFlash(__('No such user.', true));
			$this->redirect($this->Helper->url("/"));
		}
		
    	$loggedUser = $this->LoggedUser();
    	
    	if($loggedUser['id'] != $id)
		{
			$this->Session->setFlash(__('You are not this user.', true));
			$this->redirect($this->Helper->url("/"));
		}
		
    	$this->User->recursive = 0;
    	
		$currentUser = $this->User->getByID($id);
		
		if (!empty($this->data)) {

			if(array_key_exists('notification_approval', $this->data['User']))
			{
				if($this->data['User']['notification_approval'] == 1)
					$this->User->addNotification($id, 1);
				else
					$this->User->removeNotification($id, 1);
			}
			
			if(array_key_exists('notification_rejection', $this->data['User']))
			{
				if($this->data['User']['notification_rejection'] == 1)
					$this->User->addNotification($id, 2);
				else
					$this->User->removeNotification($id, 2);
			}

		}
		else
		{
			return;
		}
		
		$this->Session->setFlash(__('Notifications were updated.', true), 'default', array('class' => 'success'));
		$this->redirect($this->Helper->url("/users/edit/" . $id));	

	}
	
	function edit_picture($id = null) {
		/*
		if ( isset($this->params['id']) )
		{
			$id = $this->params['id'];
		}
        */
        
        
		if (!$id) {
			$this->Session->setFlash(__('No such user.', true));
			$this->redirect($this->Helper->url("/"));
		}
		
		$loggedUser = $this->LoggedUser();
        
		if($loggedUser['id'] != $id)
		{
			$this->Session->setFlash(__('You are not this user.', true));
			$this->redirect($this->Helper->url("/"));
		}  
    	
    	$this->User->recursive = 0;
    	$currentUser = $this->User->read(null, $id);
		
		$this->set('currentUser', $currentUser);
		$this->set('profilePic', $this->User->getPic($currentUser['User']));  
		$this->set('profileThumb', $this->User->getThumbnail($currentUser['User']));  
		
		if (empty($this->data)) {
			$this->data = $this->User->read(null, $id);
			$this->data = $this->data;
			return;
		}
		
		$this->User->set($this->data);

   		if (!empty($this->data) && is_uploaded_file($this->data['User']['Attachment']['tmp_name']))
   		{
   			$errorMessage = $this->Attachment->is_valid($this->data['User']['Attachment']);   
   			
   			if($errorMessage != "")
   			{
   				$this->Session->setFlash($errorMessage);
   				return;
   			}
   			
   			$savedProfile = $this->Attachment->save_profile($this->data['User']['Attachment'], $id, 'main');  
   			$savedLogo = $this->Attachment->save_profile($this->data['User']['Attachment'], $id, 'thumb');  

   			if($savedProfile && $savedLogo ) 
   			{
   				$this->Session->setFlash(__('Profile picture has been saved, it will be noticeable within the hour.', true), 'default', array('class' => 'success'));
		 		$this->redirect($this->Helper->url("edit_picture/" . $id));
		 		return;
   			}
   			
   			$this->Session->setFlash(__('The image could not be saved. Please, try again.', true));
			return;
		}
		
	}
	
	function delete_picture($id = null) {
		
		
		if (!$id) {
			$this->Session->setFlash(__('No such user.', true));
			$this->redirect($this->Helper->url("/"));
		}
		
		$loggedUser = $this->LoggedUser();
		
		if($loggedUser['id'] != $id)
		{
			$this->Session->setFlash(__('You are not this user.', true));
			$this->redirect($this->Helper->url("/"));
		}  
		
		$filename = "/home/downshif/public_html/services/webroot/images/profile/main/" . $loggedUser['id'] . ".png";
		if (is_writable($filename)) {
			unlink($filename);
		}

		$filename = "/home/downshif/public_html/services/webroot/images/profile/thumb/" . $loggedUser['id'] . ".png";
		
		if (is_writable($filename)) {
			$this->Session->setFlash(__('Profile picture was deleted, changes should be noticeable in an hour.', true), 'default', array('class' => 'success'));
			unlink($filename);
			$this->redirect($this->Helper->url("/users/edit_picture/" . $id));
		}
		else
		{
			$this->Session->setFlash('We were unagle to remove your profile picture.');
		}
		$this->redirect($this->Helper->url("/users/edit_picture/" . $id));
	}
	
	
	function add_friend($id = null) {
		
		$loggedUser = $this->LoggedUser();
			
		
		if( isset($loggedUser) && isset($loggedUser['id']) )
		{
			$user_id = $loggedUser['id'];
		}
		else
		{
			return;
		}
		
		$results = $this->User->addToFriends($user_id, $id);
		
		if ( $this->RequestHandler->isAjax() ) {
        
         	if ( $results ) {
        		 echo '';
         	} else {
           		echo 'query_error';
         	}       
			exit;
       	}
	}
	
	function remove_friend($id = null) {
		
		$loggedUser = $this->LoggedUser();
			
		
		if( isset($loggedUser) && isset($loggedUser['id']) )
		{
			$user_id = $loggedUser['id'];
		}
		else
		{
			return;
		}
		
		$results = $this->User->removeFromFriends($user_id, $id);
		
		if ( $this->RequestHandler->isAjax() ) {
        
         	if ( $results ) {
        		 echo '';
         	} else {
           		echo 'query_error';
         	}       
			exit;
       	}
	}
	
	
	function search($query = null) {
		
		$conditions = array('limit' => 10);
		$searchText = null;
		
		if( array_key_exists('query', $this->params['url']) )
		{
			$searchText = $this->params['url']['query'];
			$shortSearch = (strlen($searchText) < 2);
		}
		
		if($searchText == null)
		{
			if($query != null)
			{
				$searchText = $query;
				$shortSearch = (strlen($searchText) < 2);
			}
			else
			{
				$shortSearch = true;
			}
		}	
		
		$this->pageTitle = "Search Users - " . $searchText;
		$this->User->recursive = 1;
		if($shortSearch)
			$this->set('users', array());
		else
		{
			$this->paginate = $this->User->getBySearch( $searchText );
       	 	$this->set('users', $this->paginate());
		}
		
		if($shortSearch)
				$this->Session->setFlash('Search query can not be shorter than 2 characters.');
			
		$loggedUser = $this->LoggedUser();
			
		
		if( isset($loggedUser) )
		{
			$this->User->recursive = -1;
			$this->set('friends', $this->User->getFriends($loggedUser['id']));
		}
		else
			$this->set('friends', array());
		
		$this->set('User', $this->User);
		$this->set('searchText',$searchText);
    } 
    
	function force_facebook() {
		$this->Facebook->facebook->require_login();
		$this->redirect("http://apps.facebook.com/ijokers/");	
	}
	
	function service_logo($id = null, $fb_id) {

		//Configure::write('debug', 0);
        $this->action = "logo";
        $this->layout = 'image';
	}
	
	//======================================================================
	//Email Functions
	//======================================================================
	
    function sendConfirmationEmail($data) {
		$this->Email->reset();  
		$this->Email->sendAs = 'both';
		
       	//send email using the Email component
        $this->Email->to = '"'. $data['username'].'" <' . $data['email'] . '>'; 
        $this->Email->subject = Configure::read('appName') . ' - Registration Confirmation';
        $this->Email->from = Configure::read('appName') . ' <support@downshiftit.com>';
        $this->Email->replyTo = 'noreply@downshiftit.com';
		$this->Email->template = 'registration_confirmation';  
		$this->set('data', $data);  
        
        $result = $this->Email->send();

   		return $result; 
	}
	
	function sendInviteEmail($data) {
		$this->Email->reset();  
		$this->Email->sendAs = 'both';
		
		$fullName = $this->User->getProperName($data['sender']);
		$data['full_name'] = $fullName;
		$data['username'] = $data['sender']['username'];
		$data['id'] = $data['sender']['id'];
		
       	//send email using the Email component
        $this->Email->to = $data['email']; 
        $this->Email->subject = $fullName . ' invited you to join ' . Configure::read('appName');
        $this->Email->from = Configure::read('appName') . ' <support@downshiftit.com>';
        $this->Email->replyTo = 'noreply@downshiftit.com';
		$this->Email->template = 'friend_invite';  
		$this->set('data', $data);
        
        $result = $this->Email->send('Invited');
		
   		return $result; 
	}
	
	function sendForgotPasswordEmail($data) {
		$this->Email->reset();  
		$this->Email->sendAs = 'both';
		
		$data['password_link'] = 'http://'.$_SERVER['SERVER_NAME'].'/'.$this->params['controller'].'/new_password/'.$data['ticket'];
		$data['valid'] = date('m-d-Y H:i a', time() + (1 * 24 * 60 * 60));
		
       	//send email using the Email component
        $this->Email->to = '"'. $data['username'].'" <' . $data['email'] . '>'; 
        $this->Email->subject = Configure::read('appName') . ' - Password Reset';
        $this->Email->from = Configure::read('appName') . ' <support@downshiftit.com>';
        $this->Email->replyTo = 'noreply@downshiftit.com';
		$this->Email->template = 'password_reset';  
		$this->set('data', $data);  
        
        $result = $this->Email->send();

   		return $result; 
	}
	
	function isValidEmail($email){
		return eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$", $email);
	}

	//======================================================================
	//Helper Functions
	//======================================================================
	
	function setDescriptions($action)
	{
		switch ($action) {
			case "favorites":
			default:
				$meta_description = "www.todayhistory.net is dedicated to sharing world history and personally significant \"historical\" information. Sign up now so you can share the fun of what happened today or any day for that matter";
				$meta_keywords = "happened today in history, events today in history, births today in history, what happend today in history, famous people history, events history, timelines, personal timelines, this day in history, history today";
				break;
		}
		
		$this->set('meta_description', $meta_description);
		$this->set('meta_keywords', $meta_keywords);
	}
	
	function setTitle($action)
	{
		switch ($action) {
			case "invite":
				$pageTitle = "Invite Friends";
				break;
			case "reset_password":
				$pageTitle = "Reset Password";
				break;	
			case "new_password":
				$pageTitle = "Set A New Password";
				break;		
			case "index":
				return;
			case "edit":
				$pageTitle = "Edit Your Profile";
				break;	
			case "edit_picture":
				$pageTitle = "Edit Profile Picture";
				break;	
			default:
				$pageTitle = "title";
				break;
		}
		
		$this->pageTitle = $pageTitle;
	}
	
	function setViewPath($action)
	{
		if( $this->layout == "iphone")
			$this->viewPath = $this->viewPath . DS . 'iphone';
	}
	
	//======================================================================
	//iPhone App Pages
	//======================================================================
		
	function service_search($searchText = null) {
		$shortSearch = false;

		$results = array();
		
		if($shortSearch)
			$results = array();
		else 
		{
			$this->paginate = $this->User->getBySearch( $searchText );    	 	
       	 	
       	 	$users = array();
		
			$userResults = $this->paginate();
			
			foreach($userResults as $user)
			{
				$user = $this->userDetails( $user );
			
				$users[] = $user;
			}
		
       	 	$results['Results'] = $users;
       	 	$results['ResultsCount'] = $this->User->paginationCount($this->User->getBySearch( $searchText, true ));
		}
	
        $this->viewPath .= '/json';
        $this->layoutPath = 'json';
        $this->action = "output";
        
        $this->set('results', $results);
    }
	
	function service_special($type = null) {
	
		$this->setupJSON();
      
      /*
		$results = Cache::read('special_users_' . $type .'_'. $this->params['named']['page'], 'short');

		if($results)
		{
			  
			$this->set('results', $results );
			return;
		}
		*/
		$this->User->recursive = 0;
		
		if($type == "latest")
		{
			$this->paginate = $this->User->getLatest();
			$userResults = $this->paginate();
			$results['ResultsCount'] = 100;
		}
		else if($type == "active")
		{
			$userResults = $this->User->find('all', $this->User->getMostActive($this->params['named']['page']));
			$results['ResultsCount'] = 50;
		}
		else
		{
			return;
		}
		
		$userIDS = array();
		
		foreach($userResults as $temp)
		{
			$userIDS[] = $temp['User']['id'];
		}
		
		$users = array();
		
		foreach($userIDS as $temp)
		{
			$temp = $this->User->getByID($temp);
			
			if(!$temp)
				continue;
			
			$temp = $this->userDetails( $temp );
			$users[] = $temp;
		}
		
		$results['Results'] = $users;
       
       	
       	//Cache::write('special_users_' . $type .'_'. $this->params['named']['page'], $results, 'short');

		$this->set('results', $results );
	}
	
	function service_friends($user_id = null) {
		
		$this->setupJSON();
		
		$user = $this->User->getByID($user_id);
 
		$this->paginate = $this->User->getFriendsPaginate($user_id);
		$friendResults = $this->paginate(); 

		$friends = array();

		foreach($friendResults as $friend)
		{
			$friend = $this->User->getByID($friend['Friends']['friend_id']);

			if(!$friend)
				continue;
			
			$friend = $this->userDetails( $friend );
			
			$friends[] = $friend;
		}
	
		$results['Results'] = $friends;
       	$results['ResultsCount']= $this->User->getFriendsCount($user_id);
        
        $this->set('results', $results);
        
	}
	
	function service_friends_list($id = null) {
		
		$user_id = $id;
		$user = $this->User->getByID($id);
		
		$result = $this->User->getFriends($user_id);
		
        $this->setupJSON();
        
        $this->set('results', $result);
	}
	
	function service_handle_friend () {	

		$jsonData = $this->params['form']['json'];
		$jsonData = json_decode( $jsonData , true );
		
		$friend_id = $jsonData["friend_id"];
		$user_id = $jsonData["user_id"];
		$change = $jsonData["change"];
		
		
		/*
		$friend_id = 48;
		$change= "remove";
		$user_id  = 13;
		*/
		
		if($change == "add")
		{
			$results = $this->User->addToFriends($user_id, $friend_id);
		}
		else if($change == "remove")
		{
			$results = $this->User->removeFromFriends($user_id, $friend_id);
		}
		else
		{
			return;
		}
		
		return;
    }
	
	function service_view($id) {
		
		$user = $this->User->getByID($id);    
		
        $user = $this->userDetails( $user );
		
        $this->setupJSON();
        
        $this->set('results', $user);
	}
	
	function service_view_fb($fb_id) {
		
		$user = $this->User->getByFBID($fb_id);    
		
		$user = $this->userDetails( $user );
		
        $this->viewPath .= '/json';
        $this->layoutPath = 'json';
        //$this->action = "output";
        
        $this->set('results', $user);
	}
	
	function userDetails($user)
	{
		//Debugger::dump("getting_urls");
		
		if($user['User']['fbid'] != 0)
		{
			$facebookURLs = Cache::read('fb_urls_' . $user['User']['id'], 'medium');
			
			if ($facebookURLs == false) {
				$facebookURLs = $this->Facebook->getFacebookURLs( $user['User']['fbid'] );
	
				Cache::write('fb_urls_' . $user['User']['id'], $facebookURLs, 'medium');
			}
		}
		else
		{
			$facebookURLs = null;
		}

		$userID = $user['User']['id'];
			
		$user['User']['imageSmallURL'] = $this->User->getProfileURLOnly($user['User'], $facebookURLs, true, false);
		$user['User']['imageBigURL'] = $this->User->getProfileURLOnly($user['User'], $facebookURLs, false, false);

		$urls = array();
		$urls['imageSmallURL'] = $user['User']['imageSmallURL'];
		$urls['imageBigURL'] = $user['User']['imageBigURL'];

		$friendCount = $this->User->getFriendsCount($userID);
		$favoritesCount = $this->User->getFaveCount($userID);
		$itemCount = $this->Event->find('count', array('conditions' => array('user_id' => $userID, 'status' => 1)));
		$privateCount = $this->Event->find('count', array('conditions' => array('user_id' => $userID, 'status' => 3)));
		$commentCount = $this->User->Comments->find('count', array('conditions' => array('creator_id' => $userID)));
		
		$user['User']['friendCount'] = $friendCount;
		$user['User']['faveCount'] = $favoritesCount;
		$user['User']['itemCount'] =	$itemCount;
		$user['User']['privateCount'] =	$privateCount;
		
		$user['User']['commentCount'] = $commentCount;

		$created = explode('-', substr($user['User']['created'], 0,10));
		$user['User']['created'] = $created[1] . "/" . $created[2] . "/" . $created[0];
		
		if($user['User']['birthdate'] != "0000-00-00")
		{
			$dob = explode('-', substr($user['User']['birthdate'], 0,10));
			$user['User']['birthdate'] = $dob[1] . "/" . $dob[2] . "/" . $dob[0];
		}
		else
		{
			$user['User']['birthdate'] = "";
		}
		
		return $user;
	}
	
}
?>