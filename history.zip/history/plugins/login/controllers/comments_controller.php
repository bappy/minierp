<?php
class CommentsController extends AppController {

	var $name = 'Comments';
	var $helpers = array('Html', 'Form', 'Ajax', 'Time');
	var $components = array('RequestHandler');

	function beforeFilter() {
		parent::beforeFilter();
		$this->Auth->allow('index', 'add', 'service_index');
	}

	function index($model, $id) {
	
		$this->Comment->current = "no-cache";
		
		$this->paginate = array(
			'conditions' => array(
				'Comment.model' => $model,
				'Comment.foreign_key' => $id,
			),
			'contain' => array(
				'User',
			),
			'order' => array('Comment.id DESC'), 
			'limit' => 10,
			'page' => 'first',
		);
		$this->Comment->recursive = 0;
		$this->set('comments', $this->paginate());
		$this->set('_model', $model);
		$this->set('User', $this->User);
		
		$this->set('_foreignKey', $id);
	}

	function add($model = null, $id = null) {
		
		if (!empty($this->data)) {
		
			$loggedUser = $this->LoggedUser();
			
			if( isset($loggedUser) && isset($loggedUser['id']) )
			{
				$this->data['Comment']['creator_id'] = $loggedUser['id'];
			}
			else
			{
				return;
			}
			
			$model = Set::extract($this->data, 'Comment.model');
			$id = Set::extract($this->data, 'Comment.foreign_key');
			$this->data['Comment']['type'] = 3;
			
			$this->Comment->create();
			if ($this->Comment->save($this->data)) {
				$this->Session->setFlash(__('The Comment has been saved', 'default', array('class' => 'success')));
				$this->data = array();
				$this->set('successful', true);
			} else {
				$this->Session->setFlash(__('The Comment could not be saved. Please, try again.', true));
			}
		}
		else {
			$this->data = array(
				'Comment' => array(
					'model' => $model,
					'foreign_key' => $id,
				)
			);
		}
		$this->set('_model', $model);
		$this->set('_foreignKey', $id);
	}
	
	function delete($id = null) {
		
		if (!$id) {
			return;
		}
		
		$loggedUser = $this->LoggedUser();
		$comment = $this->Comment->read(null, $id);
		
		if(!$loggedUser)	
			return;
		else
		{
			if($comment['Comment']['creator_id'] != $loggedUser['id'])
				return;
		}
		
		if ($this->Comment->del($id)) {
			$this->Session->setFlash(__('Comment deleted', 'default', array('class' => 'success')));
			$this->redirect("/events/view/" . $comment['Comment']['foreign_key']);
		}
		$this->Session->setFlash(__('Event comment was not deleted', true));
	}
	
	//======================================================================
	//Service Functions
	//======================================================================
	
	function service_index($model, $id) {
		$this->setupJSON();
		
		$comments = Cache::read('comments_' . $model . '_'. $id .'_'. $this->params['named']['page'], 'short');
			
		if ($comments != false) {
			$this->set('results', $comments);
			return;		
		}
			
		$this->Comment->current = "no-cache";
		
		$this->paginate = array(
			'fields' => $this->Comment->fields,
			'conditions' => array(
				'Comment.model' => $model,
				'Comment.foreign_key' => $id,
			),
			'contain' => array(
				'User',
			),
			'order' => array('Comment.id DESC'), 
			'limit' => 10,
			'page' => 'first',
		);
		
		$results = $this->paginate();
		
		$users = array();
		$comments = array();
		
		foreach($results as $result)
		{
			
			$userID = $result['User']['id'];
			
			if($result['User']['fbid'] != 0)
			{
				$facebookURLs = Cache::read('fb_urls_' . $userID, 'medium');
				if ($facebookURLs == false) {
					$facebookURLs = $this->Facebook->getFacebookURLs( $result['User']['fbid'] );
					Cache::write('fb_urls_' . $userID, $facebookURLs, 'medium');
				}
			}
			else
			{
				$facebookURLs = null;
			}

			$result['User']['imageSmallURL'] = $this->User->getProfileURLOnly($result['User'], $facebookURLs, true, false);

			App::import('Helper', 'Time');
			$time = new TimeHelper();

			$result['Comment']['created'] = $time->relativeTime($result['Comment']['created']);
			
			$comments[] = $result;
		}

		$results['Results'] = $comments;
       	$results['ResultsCount']= count($comments);
       	       
       	Cache::write('comments_' . $model . '_'. $id .'_'. $this->params['named']['page'], $results, 'short');
       	
		$this->set('results', $results);
	}
	
	function service_latest($model, $id) {
		$this->setupJSON();
		
		$this->Comment->current = "no-cache";
		
		$this->paginate = array(
			'fields' => $this->Comment->fields,
			'conditions' => array(
				'Comment.model' => $model,
				'Comment.foreign_key' => $id,
			),
			'contain' => array(
				'User',
			),
			'order' => array('Comment.id DESC'), 
			'limit' => 5,
			'page' => 'first',
		);
		
		$results = $this->paginate();
		
		$users = array();
		$comments = array();
		
		foreach($results as $result)
		{
			
			$userID = $result['User']['id'];
			
			if($result['User']['fbid'] != 0)
			{
				$facebookURLs = Cache::read('fb_urls_' . $userID);
				if ($facebookURLs == false) {
					$facebookURLs = $this->Facebook->getFacebookURLs( $result['User']['fbid'] );
					Cache::write('fb_urls_' . $userID, $facebookURLs, 'short');
				}
			}
			else
			{
				$facebookURLs = null;
			}

			$result['User']['imageSmallURL'] = $this->User->getProfileURLOnly($result['User'], $facebookURLs, true, false);

			App::import('Helper', 'Time');
			$time = new TimeHelper();

			$result['Comment']['created'] = $time->relativeTime($result['Comment']['created']);
			
			$comments[] = $result;
		}
		
		$results['Results'] = $comments;
       	$results['ResultsCount']= count($comments);
       	
		$this->set('results', $results);
	}
	
	function service_add() {
		
		$jsonData = $this->params['form']['json'];
		$jsonData = json_decode( $jsonData , true );
		
		$item_id = $jsonData["item_id"];
		$user_id = $jsonData["user_id"];
		$comment = $jsonData["comment"];
		

		$this->data['Comment']['creator_id'] = $user_id;
		$this->data['Comment']['model'] = "events";
		$this->data['Comment']['foreign_key'] = $item_id;
		$this->data['Comment']['comment'] = $comment;
		$this->data['Comment']['type'] = 3;
		
		$this->Comment->create();
		if ($this->Comment->save($this->data)) {

    		$result = $this->Comment->getByID($this->Comment->id);
			
			$userID = $result['User']['id'];
			
			if($result['User']['fbid'] != 0)
			{
				$facebookURLs = Cache::read('fb_urls_' . $userID, 'medium');
				if ($facebookURLs == false) {
					$facebookURLs = $this->Facebook->getFacebookURLs( $result['User']['fbid'] );
					Cache::write('fb_urls_' . $userID, $facebookURLs, 'medium');
				}
			}
			else
			{
				$facebookURLs = null;
			}

			$result['User']['imageSmallURL'] = $this->User->getProfileURLOnly($result['User'], $facebookURLs, true, false);
			$result['Comment']['created'] = "just now";
			
			$this->set('results', $result);
		
			$this->viewPath .= '/json';
       		$this->layoutPath = 'json';
        	$this->action = "output";
		}
	}
	
}
?>