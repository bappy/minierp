<?php 

class ProjectFilesController extends AppController {
    function add() {
    	
    	$user = $this->loggedUser();
    	$this->set('userID', $user['id']);
    	
    	Debugger::dump($this->data['ProjectFile'] );
    	
        if (!empty($this->data) &&
             is_uploaded_file($this->data['ProjectFile']['File']['tmp_name'])) {
            $fileData = fread(fopen($this->data['ProjectFile']['File']['tmp_name'], "r"),
                                     $this->data['ProjectFile']['File']['size']);

            $this->data['ProjectFile']['name'] = $this->data['ProjectFile']['File']['name'];
            $this->data['ProjectFile']['type'] = $this->data['ProjectFile']['File']['type'];
            $this->data['ProjectFile']['size'] = $this->data['ProjectFile']['File']['size'];
            $this->data['ProjectFile']['data'] = $fileData;

			Debugger::dump("Saved");
            //$this->ProjectFile->save($this->data);
            
        }
    }
    
   function download($id) {
   
    	Configure::write('debug', 0);
    	$file = $this->ProjectFile->findById($id);

    	header('Content-type: ' . $file['ProjectFile']['type']);
    	header('Content-length: ' . $file['ProjectFile']['size']); // some people reported problems with this line (see the comments), commenting out this line helped in those cases
    	header('Content-Disposition: attachment; filename="'.$file['ProjectFile']['name'].'"');
    	echo $file['ProjectFile']['data'];

    	exit();
	}

	function show($id) {
		Configure::write('debug', 0);
    	$this->ProjectFile->recursive=-1;
    	$file = $this->ProjectFile->findById($id);
		
    	if(!isset($file['ProjectFile']['name']) || substr($file['ProjectFile']['type'],0,5)!='image'){
    		print_r ($file);
        	echo 'Not an image file';
        	exit;
    	}
        
    	header('Content-type: ' . $file['ProjectFile']['type']); 
    	echo $file['ProjectFile']['data']; 
        exit();
    }

}

?>