<?php
/*
qpEPv/3/lQCL3g8/nQ211sEvRlkTs+31RMlLNq4w
AKIAJUC5LOYP6CUM5FGQ
the first one is the secret access key
the second is the access key id
bucket name is today_in_history
*/
App::import('Vendor', 'amazon/s3');
class readimageComponent extends Object
{
    //called before Controller::beforeFilter()
    function uploadImage($url, $file = '', $awsAccessKey = 'AKIAJUC5LOYP6CUM5FGQ', $awsSecretKey = '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', $bucket_name = 'today_in_history')
    {
        $im = $this->save_image($url, WWW_ROOT . '/img/uploads/' . $file["filename"] . '.' . $file["file_ext"]);

        if (!empty($file["file_ext"]))
            $image = WWW_ROOT . '/img/uploads/' . $file["filename"] . '.' . $file["file_ext"];
        else
            $image = WWW_ROOT . '/img/uploads/' . $file["filename"] . '.jpg';

        $s3 = new S3($awsAccessKey, $awsSecretKey); //create a new bucket
        $s3->putBucket($bucket_name, S3::ACL_PUBLIC_READ);
        $out = array();

        if ($s3->putObjectFile($image, $bucket_name, $file["filename"], S3::ACL_PUBLIC_READ)) {
            {

                $out["url"] = "http://" . $bucket_name . ".s3.amazonaws.com/" . $file["filename"];
                $out["upload"] = true;
                unlink($image);
                return $out;
            }
        } else {
            return $out["upload"] = false;
        }


    }

    function  show($file_name, $awsAccessKey = 'AKIAJUC5LOYP6CUM5FGQ', $awsSecretKey = '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', $bucket_name = 'today_in_history')
    {

        $s3 = new S3($awsAccessKey, $awsSecretKey);
        $bucket_contents = $s3->getBucket($bucket_name);
        debug($bucket_contents);
        foreach ($bucket_contents as $file) {

            $fname = $file['name'];
            $furl = "http://" . $bucket_name . ".s3.amazonaws.com/" . $fname;
            echo "<a href=\"$furl\">$fname</a><br />";
        }

    }


    /* function inputFile($file, $md5sum = true) {
         if (!file_exists($file) || !is_file($file) || !is_readable($file)) {
             trigger_error('S3::inputFile(): Unable to open input file: ' . $file, E_USER_WARNING);
             return false;
         }
         return array(
             'file' => $file,
             'size' => filesize($file),
             'md5sum' => $md5sum !== false ? (is_string($md5sum) ? $md5sum :
                 base64_encode(md5_file($file, true))) : '',
         );
     }
    */


   /* function  Ucurl($url, $dest)
    {
        $ch = curl_init($url);
        $fp = fopen($dest, 'wb');
        curl_setopt($ch, CURLOPT_FILE, $fp);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_exec($ch);
        curl_close($ch);
        fclose($fp);


    }
   */

    function save_image($img,$fullpath){


        $ch = curl_init ($img);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_BINARYTRANSFER,1);
        $rawdata=curl_exec($ch);
        curl_close ($ch);
        if(file_exists($fullpath)){
            unlink($fullpath);
        }
        $fp = fopen($fullpath,'x');
        fwrite($fp, $rawdata);
        fclose($fp);
    }

    function  url_extension($url)
    {


        $filename = explode('/', $url);
        $length = count($filename);
        $file = explode(".", $filename[$length - 1]);
        $array["filename"] = $file[0];
        $array["file_ext"] = pathinfo($filename[$length - 1], PATHINFO_EXTENSION);
        return ($array);

    }

function LinkuploadImage($url,$file, $awsAccessKey = 'AKIAJUC5LOYP6CUM5FGQ', $awsSecretKey = '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', $bucket_name = 'today_in_history')
{


    if (!empty($file["file_ext"]))
    {
        $image = WWW_ROOT . '/img/uploads/' . $file["filename"] . '.' . $file["file_ext"];

    }
    else
        $image = WWW_ROOT . '/img/uploads/' . $file["filename"] . '.jpg';


    $s3 = new S3($awsAccessKey, $awsSecretKey); //create a new bucket
    $s3->putBucket($bucket_name, S3::ACL_PUBLIC_READ);
    $out = array();

    if ($s3->putObjectFile($image, $bucket_name, $file["filename"], S3::ACL_PUBLIC_READ)) {
        {

            $out["url"] = "http://" . $bucket_name . ".s3.amazonaws.com/" . $file["filename"];
            $out["upload"] = true;
            unlink($image);
            return $out;
        }
    } else {
        return $out["upload"] = false;
    }

}

}
?>
