<?php
//include("headline_quotes_controller.php");
class EventsController extends AppController {

	var $name = 'Events';
    var $helpers = array('Javascript', 'Ajax','Js' => array('Jquery'),"EUtility","CustomnewDate","Utility");
   // var $helpers = array('Javascript',"EUtility", 'Ajax','CustomDate','Js' => array('Jquery'));
    var $components = array('RequestHandler','Imager','readimage');


   function lookEvent($day,$month,$category)
    {
        // $this->Event->unBindModel(array("User"));

        /*$this->loadModel('Event');
        $this->Event->unbindModel(
            array('belongsTo' => array('User'))
        );

        $this->Event->unbindModel(
            array('belongsTo' => array('Category'))
        );
        $this->recursive=-1;
        $options['joins'] = array(
            array('table' => 'headlines',
                'alias' => 'Headline',
                'type' => 'Left',
                'fields'=>array("Event.name"),
                'conditions' => array(
                    'Event.id=Headline.headline_quote_id'
                )
            )
        );
        */
        $options['conditions']=array('AND'=>array("Event.category_id"=>$category,"Event.day"=>$day,"Event.month"=>$month)) ;
        $options['order']=array('Event.day,Event.month,Event.year DESC');
        $events = $this->Event->find('all', $options);

        return $events;
    }

   /* function  searchEvent($day,$month,$category)
    {
        $options['conditions']=array('AND'=>array("Event.category_id"=>$category,"Event.day"=>$day,"Event.month"=>$month,"Headline.headline_quote_id"=>null)) ;
        $this->Event->find("all",$options);

    }
   */



    function  get_date($data,$params)
    {


        if($params['isAjax'])
        {




            if(((isset($params["form"]["month"]))||(isset($params["form"]["day"]))))
            {
                $month=$params["form"]["month"];
                $day=$params["form"]["day"];
                $array["day"]=$day;
                $array["month"]=$month;
                return $array;


            }
            else{
                $day=$this->params["named"]["day"];
                $month=$this->params["named"]["month"];



            }
            $array["day"]=$day;
            $array["month"]=$month;
            return $array;

        }
        else
        {  //not ajax
            if(!empty($data))
            {


                $month=$data["HeadlineQuote"]["month"];
                $day=$data["HeadlineQuote"]["day"];
                $array["day"]=$day;
                $array["month"]=$month;
                return $array;



            }
            else if(!empty($params["named"]))
            {
                $day=$params["named"]["day"];
                $month=$params["named"]["month"];
                $array["day"]=$day;
                $array["month"]=$month;
                return $array;
            }
            else {
                $today=  date("d:m");
                $today=explode(":",$today);
                $day=$today[0];
                $month=$today[1];
            }




        }

        $array["day"]=$day;
        $array["month"]=$month;

        return $array;
    }

    function index($M='',$D='') {

        if($this->params['isAjax'])
        {


          $day=$this->params["form"]["day"];
          $month=$this->params["form"]["month"];

        $this->set(compact('day',$day));
        $this->set(compact('month',$month));

        $events=  $this->lookEvent($day,$month,36);
        $births = $this->lookEvent($day,$month,37);
        $deaths = $this->lookEvent($day,$month,38);
        $holidays = $this->lookEvent($day,$month,39);


        $this->set(compact('day'));
        $this->set(compact('month'));
        $this->set(compact('events'));
        $this->set(compact('births'));
        $this->set(compact('deaths'));
        $this->set(compact('holidays'));
		}
        else if(!empty($D)&&(!empty($M)))
        {
            $day=$D;
            $month=$M;

            $this->set(compact('day'));
            $this->set(compact('month'));
            $events=  $this->lookEvent($day,$month,36);
            $births = $this->lookEvent($day,$month,37);
            $deaths = $this->lookEvent($day,$month,38);
            $holidays = $this->lookEvent($day,$month,39);

            $this->set(compact('day'));
            $this->set(compact('month'));
            $this->set(compact('events'));
            $this->set(compact('births'));
            $this->set(compact('deaths'));
            $this->set(compact('holidays'));

        }
        else
        {

       $day = date("d");
        $month = date("m");


        $this->set(compact('day',$day));
        $this->set(compact('month',$month));
        $events=  $this->lookEvent($day,$month,36);
        $births = $this->lookEvent($day,$month,37);
        $deaths = $this->lookEvent($day,$month,38);
        $holidays = $this->lookEvent($day,$month,39);

        $this->paginate = array(
            'conditions' =>array("AND"=>array('Event.day' =>$day,'Event.month' =>$month)),
            'limit' => 30
        );
        $this->Event->recursive = 0;
        $this->set(compact('day'));
        $this->set(compact('month'));
        $this->set(compact('events'));
        $this->set(compact('births'));
        $this->set(compact('deaths'));
        $this->set(compact('holidays'));

        }

    }

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid event', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('event', $this->Event->read(null, $id));
	}
    function process_link_id($url)
    {
        //$array=>$url_name
        $k=0;
        $store=array();



        foreach($url as $key=> $arr) //for new
        {


           if(($this->check_duplicate($arr)))
           {


             $path=(parse_url($arr));
             $path=explode("/",$path["path"]);
             $data["id"]=NULL;
             $data["imageurl"]=$this->w3amazonURL("http:".$this->Imager->check_ajax($arr));
             $data["name"]=str_ireplace('_',' ',$path[2]);
             $data["url"]=$url[$key];


            if(!empty( $data["imageurl"]))
            {
            $this->Event->Link->create();

            if($this->Event->Link->save($data))
            {
             $id=$this->Event->Link->getInsertID();
            if(!in_array($id,$store))
            {
            $store[$k]=$id;
            $k++;
            }

           }




            }
           }
            else
            {
               $id2=$this->get_link_id($url[$key]);
                if(!in_array($id2,$store))
                {
                    $store[$k]=$id2;
                $k++;
                }

            }






        }

        $st=implode(";",$store);
        return $st;
    }

    function  get_link_id($url)
    {
     $this->loadModel("Link");
   $info=$this->Link->findByurl(trim($url));

    if( empty($info["Link"]["imageurl"]))
    {


        $image=$this->w3amazonURL(trim($url));
        $this->Link->id = $info["Link"]["id"];
        $this->Link->saveField("imageurl",$image);

        return $info["Link"]["id"];
    }
        else
        {

            return $info["Link"]["id"];
        }
    }
    function  process_url($url)
    {
        $store=array();
        foreach($url as $u)
            $store[]=$u;

        return $store;
    }

    function put_link($array,$url)
    {


      $store=$this->process_url($url);

        $k=0;
       $array=explode(";",$array);
        foreach($array as $key=>$arr)
        {

       $info=$this->Event->Link->read("imageurl",$arr);

       $link_urk=$this->Event->Link->read("url",$arr);


        if((empty($info["Link"]["imageurl"])||(!getimagesize($info["Link"]["imageurl"])))&&($this->check_duplicate($link_urk["Link"]["url"])))
        {
            $image=$this->w3amazonURL("http:".$store[$k]);


            $this->Event->Link->id = $arr;
            $this->Event->Link->saveField("imageurl",$image);


        }



            $k++;
        }


    }


    function check_duplicate($url)
    {

        $info = $this->Event->Link->find('count', array('conditions' => array('Link.url' =>trim($url))));

        if(!$info) //no link
            return true;
        return false;
    }

    function add()
    {


     if(!empty($this->data))
        {


           $arr=$this->data;
            if (!isset($this->data["Link"]["url_name"]))
                $this->data["Link"]["url_name"]='';

            if((!isset($this->data["Link"]["imageurl"])))
            {

                $this->Session->setFlash(__('Could Not Load URL,PLEASE TRY AGAIN', true));
                $this->redirect($this->referer());

            }


         $store= $this->process_link_id($this->data["Link"]["url_name"]);



       // $this->put_link($store,$this->data["Link"]["imageurl"]);
         $this->data["Event"]["link"]=$store;
        if(($this->data["Event"]["category_id"]==36)||( $this->data["Event"]["category_id"]==39))

            $this->data["Event"]["name"]="";
          $this->Event->create();
          if($this->Event->save($this->data))
          {
        $this->Session->setFlash(__('Successfully Inserted ', true));
        $insertID=$this->Event->getInsertID();
         //$this->redirect(array('controller' => 'Events', 'action' => 'index'));
          }

          $listUrl=$this->data["Link"]["url_name"];

           foreach($listUrl as $list)
           {




            $this->Event->Events_link->create();
            $data['link_id']=$this->linkID($list);
            $data['event_id']=$insertID;
            if($this->DuplicateEntry($data['event_id'],$data["link_id"]))
		{
		$this->Event->Events_link->saveAll($data);
		}
           }

        }

        $users = $this->Event->User->find('list');
        $categories = $this->Event->Category->find('list');
        $headlines = $this->Event->Headline->find('list');
        $this->loadModel("Link");
        $this->Event->recursive = 0;
        $events=$this->Link->find("all");
        $this->set(compact('users', 'categories', 'headlines','events'));


    }

function  DuplicateEntry($eventID,$linkID)
{
    
if(($linkID==NULL)||(empty($linkID)))
        return false;

    $num = $this->Event->Events_link->find('count', array('conditions' =>array("AND"=>array('Events_link.link_id' =>$linkID,'Events_link.event_id' =>$eventID))));
    if($num>0)
        return false;
    return true;
}
function linkID($url)
{
    $num = $this->Event->Link->find('first', array('conditions' => array('Link.url' => trim($url))));

        return $num["Link"]["id"];

}

	function edit($id = null) {


		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid event', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
            if(($this->data["Event"]["category_id"]==36)||( $this->data["Event"]["category_id"]==39))
                $this->data["Event"]["name"]="";

		if(empty($this->data["Event"]["event"]))
            	{
                $this->Session->setFlash(__('The event field is empty', true));
                $this->redirect(array('action' => 'index'));
            	}
            else if ($this->Event->save($this->data)) {

				$this->Session->setFlash(__('The event has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The event could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Event->read(null, $id);

		}


		$users = $this->Event->User->find('list');
		$categories = $this->Event->Category->find('list');
		$headlines = $this->Event->Headline->find('list');
        $conditions = array("Events_link.event_id" =>$id);
        $events = $this->Event->Events_link->find('all',array('conditions' => $conditions));
		$this->set(compact('users', 'categories', 'headlines','events','id'));
	}

    function isValidURL($url)
    {
        return preg_match('|^http(s)?://[a-z0-9-]+(.[a-z0-9-]+)*(:[0-9]+)?(/.*)?$|i', $url);
    }
        
         function w3amazonURL($url)
         {
      //if(!$this->isValidURL($url))
        //{
       // return false;
        //}

        $info=$this->readimage->url_extension($url);

        if(empty($info["filename"]))
          return $url;
        $image=$this->readimage->uploadImage($url,$info);

        if($image["upload"])
            return $image["url"];
        }
	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for event', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->Event->delete($id)) {
			$this->Session->setFlash(__('Event deleted', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Event was not deleted', true));
		$this->redirect(array('action' => 'index'));
	}


    function get_link_url()
    {

        if (!empty($this->params['requested']))
        {
          $params=$this->params;
         //$this->loadModel("Link");


        $condition=   array(
        'conditions' => array('Link.id' =>$params["pass"]), //array of conditions
        'recursive' => 1, //int
        'fields' => array('Link.imageurl','Link.id','Link.url'), //array of field names
              );

        $info=$this->Event->Link->find("all",$condition);
      return $info;
        }



    }

    function get_url()
    {
        if (!empty($this->params['requested']))
        {
            $params=$this->params;
            $this->loadModel("Link");


            $condition=   array(
                'conditions' => array('Link.id' =>$params["pass"]), //array of conditions
                'recursive' => 1, //int
                'fields' => array('Link.url','Link.id'), //array of field names
            );

            $info=$this->Link->find("all",$condition);
            return $info;
        }



    }



    function make_it_main()
    {
        $this->debug=false;

        $params=$this->params;
        $id=$params["form"]["id"];
        $eid=$params["form"]["eid"];

        $this->Event->updateAll( array('Event.link_id' => $id),
            array('Event.id'=>$eid));


        $this->loadModel("Link");
       $condition=   array(
            'conditions' => array('Link.id' =>$id), //array of conditions
            'recursive' => 1, //int
            'fields' => array('Link.imageurl'), //array of field names
        );

        $info=$this->Link->find("all",$condition);
        $this->set(compact('info'));


    }

    function delete_it_main()
    {
       $this->debug=false;
        $this->autoRender = false;
        $params=$this->params;
        $this->layout='ajax';

        $id=$params["form"]["id"];
        $eid=$params["form"]["eid"];
        $k=$params["form"]["k"];

        /*$LINK_IDS=array();
        $LINK_IDS = $this->Event->read('link',$eid);


        $LINK_IDS=$LINK_IDS["Event"]["link"];
$store=array();
        $LINK_IDS=explode(";",$LINK_IDS);
        $g=0;
        foreach($LINK_IDS as $ids)
        {
            if($k<>$g)
                $store[]=$ids;
            $g++;


        }
     $store=implode(";",$store);

           $this->Event->id = $eid;
        $this->Event->saveField('link',$store);
*/
        /*$con=array(
                    'conditions' => array("AND"=>array('Events_link.event_id' => $eid,'Events_link.link_id' => $id)), //array of conditions
                    'fields' => array('Events_link.id'), //array of field names

                );
*/
           //    $id=$this->Event->Events_links->find("first",$con);


               //$this->Event->Events_links->delete($id,$eid);

        $this->Event->query("Delete from events_links where link_id=$id and event_id=$eid");




    }


    function load_it_main()
    {

        if(($this->params["isAjax"]))
        {

        $this->debug=false;
        if(isset($this->params["url"]["eid"]))
            $id=$this->params["url"]["eid"];
        else     $id=$this->params["form"]["eid"];

        //$day=$this->params["url"]["day"];
         //   $month=$this->params["url"]["month"];
        //$this->data = $this->Event->read(null, $id);
        $conditions = array("Events_link.event_id" =>$id);
        $events = $this->Event->Events_link->find('all',array('conditions' => $conditions));
            $this->set(compact('events'));
          //  $this->set(compact('day'));
           // $this->set(compact('month'));



        }

    }

    function wamazonURL($url)
    {
        $info=$this->readimage->url_extension($url);


        if(empty($info["filename"]))
            return $url;
        $image=$this->readimage->uploadImage($url,$info);


        if($image["upload"])
            return $image["url"];
    }

    function add_events()
    {
         if(($this->params["isAjax"]))
         {

             $this->layout='ajax';

             $id=$this->params["form"]["id"];
             $url=trim($this->params["form"]["url"]);


             $count = $this->Event->Link->find('count', array('conditions' => array('Link.url' => trim($url))));

         if($count) //has link
         {
         $this->insert_events($url,$id);
        }
        else //insert link into db
        {




            $path=parse_url($url);

            $url=$this->params["form"]["url"];
            $path=explode("/",$path["path"]);

            $data["id"]=NULL;


           $data["imageurl"]=$this->wamazonURL("http:".$this->Imager->check_ajax(trim($url)));
            //$imgurl=$data["imageurl"];

            $this->set(compact('url'));
            $data["name"]= str_replace('_',' ',html_entity_decode($path[2]));
            $data["url"]=$url;


            $this->Event->Link->create();
            $this->Event->Link->save($data);
            $insert_id=$this->Event->Link->getInsertID();
          $this->insert_events($url,$id,$insert_id);

        }


         }//is ajax


   }


        function insert_events($url,$id,$insert_id='')
        {

           if(empty($insert_id))
           {
            $info=$this->Event->Link->findByUrl(trim(($url)));
            $info=$info["Link"]["id"];
           }
            else  $info=$insert_id;
               if($this->DuplicateEntry($id,$info))
           {
               $data["event_id"]=$id;
               $data["link_id"]=$info;
               $this->Event->Events_link->save($data);
           }

    }

    function insert_new_events($url,$insert_id,$id)
    {



         $ids=$this->Event->read("link",$id);
        if(!empty($ids["Event"]["link"]))
        {
            $Nid=explode(";",$ids["Event"]["link"]);
            $Nid[count($Nid)]=$insert_id;
            $Nid=implode(";",$Nid);
            $this->Event->id=$id;
            $this->Event->saveField("link",$Nid);

        }
        else
        {

            $this->Event->id=$id;
            $this->Event->saveField("link",$insert_id);
        }

    }


    function  load_events()
    {

        if(($this->params["isAjax"]))
        {


          $this->layout='ajax';
           $id=$this->params["form"]["id"];
            $event=$this->Event->findAllById($id);
            $this->set(compact('event'));

        }


    }
function get_year()
{

if (!empty($this->params['requested'])) {


$this->Event->id=$this->params['pass'];
$year = $this->Event->read('year');

return $year['Event']['year'];
}

return '';
}




    function  insert_edit()
    {



      if($this->params["isAjax"])
      {
          $this->layout='ajax';
       $event=  $this->params["form"]["event"];
       $value=  $this->params["form"]["value"];
      if($this->DuplicateEntry($event,$value))
      {
          $data["event_id"]=$event;
          $data["link_id"]=$value;
        $this->Event->Events_link->save($data);
      }

      }

    }


}