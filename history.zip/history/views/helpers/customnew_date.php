<?php
/* /app/views/helpers/link.php (using other helpers) */
class CustomnewDateHelper  extends AppHelper {
    var $helpers = array('Html');

    function Month($curr_month=null,$name="data[Event][month]") {

        $month = array (0=>"Month",1=>"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
        $select="<select id=\"HeadlineQuoteTimeMonth\" name=".$name."".">";
        foreach ($month as $key => $val) {
            $select .= "\t<option value=\"".$key."\"";
            if ($key == $curr_month) {
                $select .= " selected=\"selected\">".$val."</option>\n";
            } else {
                $select .= ">".$val."</option>\n";
            }
        }
        $select .= "</select>";
        echo $select;



    }

    function  Day($id=null,$name="data[Event][day]")
    {
        ?>


    <select name="<?php echo $name; ?>">
        <option  value="">Day</option>
            <?php
            for($i=1;$i<=31;$i++)
            {
                if($i==$id)

                {
                    ?>

                    <option value="<?php echo $i  ?>" selected="selected">
                        <?php echo $i;?>
                    </option>


                    <?php
                }
                else
                {
                ?>
            <option value="<?php echo $i ?>">
                <?php echo $i;?>
            </option>
                <?php }?>
            <?php }?>
        </select>

        <?php

    }


    function Year($year='',$name="data[Event][year]")
    {

        ?>
   <?php /*
    <select id="sel_yr" name="<?php echo $name; ?>">
        <?php
        for($i=0;$i<50;$i++)
        {
            if($i==0)
            {
                ?>

                <option  selected="selected" value="<?php echo $year ?>"><?php echo $year; ?></option>

                <?php

            }
            else

            {?>
                <option  value="<?php echo $year ?>"><?php echo $year; ?></option>
                <?php

            }
            $year--;
        }
        ?>
    </select>
    <?php
*/


        ?>

        <input id="sel_yr" type="text" value="<?php echo $year; ?>" size="5" name="data[Event][year]">



<?php

    }


}
?>
