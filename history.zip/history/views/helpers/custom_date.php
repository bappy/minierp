<?php
/* /app/views/helpers/link.php (using other helpers) */
class CustomDateHelper extends AppHelper {
    var $helpers = array('Html');

    function Month($curr_month=null) {

        $month = array (0=>"Month",1=>"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
        $select = "<select id=\"HeadlineQuoteTimeMonth\" name=\"month\">\n";
        foreach ($month as $key => $val) {
            $select .= "\t<option value=\"".$key."\"";
            if ($key == $curr_month) {
                $select .= " selected=\"selected\">".$val."</option>\n";
            } else {
                $select .= ">".$val."</option>\n";
            }
        }
        $select .= "</select>";
        echo $select;



    }

    function  Day($id=null)
    {
        ?>


    <select id="HeadlineQuoteTimeDay" name="day">
        <option  value="">Day</option>
            <?php
            for($i=1;$i<=31;$i++)
            {
                if($i==$id)

                {
                    ?>

                    <option value="<?php echo $i  ?>" selected="selected">
                        <?php echo $i;?>
                    </option>


                    <?php
                }
                else
                {
                ?>
            <option value="<?php echo $i ?>">
                <?php echo $i;?>
            </option>
                <?php }?>
            <?php }?>
        </select>

        <?php

    }


    function Year($year='')
    {

/*        ?>
        <select name="year">
    <?php
        for($i=0;$i<50;$i++)
        {
            if($i==0)
            {
            ?>

         <option  selected="selected" value="<?php echo $year ?>"><?php echo $year; ?></option>

            <?php

        }
            else

        {?>
            <option  value="<?php echo $year ?>"><?php echo $year; ?></option>
     <?php

        }
            $year--;
        }
    ?>
</select>
    <?php





}
*/?>
    <input id="year" type="text" value="<?php echo $year; ?>" size="5" name="data[Event][year]">

<?php }

}
?>
