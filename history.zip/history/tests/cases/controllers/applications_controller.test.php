<?php
/* Applications Test cases generated on: 2012-08-12 08:12:58 : 1344759178*/
App::import('Controller', 'Applications');

class TestApplicationsController extends ApplicationsController {
	var $autoRender = false;

	function redirect($url, $status = null, $exit = true) {
		$this->redirectUrl = $url;
	}
}

class ApplicationsControllerTestCase extends CakeTestCase {
	var $fixtures = array('app.application', 'app.category');

	function startTest() {
		$this->Applications =& new TestApplicationsController();
		$this->Applications->constructClasses();
	}

	function endTest() {
		unset($this->Applications);
		ClassRegistry::flush();
	}

	function testIndex() {

	}

	function testView() {

	}

	function testAdd() {

	}

	function testEdit() {

	}

	function testDelete() {

	}

}
