<?php
/* HeadlineEvent Test cases generated on: 2012-08-12 08:13:14 : 1344759194*/
App::import('Model', 'HeadlineEvent');

class HeadlineEventTestCase extends CakeTestCase {
	var $fixtures = array('app.headline_event', 'app.event', 'app.user', 'app.category', 'app.application', 'app.headline');

	function startTest() {
		$this->HeadlineEvent =& ClassRegistry::init('HeadlineEvent');
	}

	function endTest() {
		unset($this->HeadlineEvent);
		ClassRegistry::flush();
	}

}
