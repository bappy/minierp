<?php
/* HeadlineQuote Test cases generated on: 2012-08-12 08:13:21 : 1344759201*/
App::import('Model', 'HeadlineQuote');

class HeadlineQuoteTestCase extends CakeTestCase {
	var $fixtures = array('app.headline_quote', 'app.headline');

	function startTest() {
		$this->HeadlineQuote =& ClassRegistry::init('HeadlineQuote');
	}

	function endTest() {
		unset($this->HeadlineQuote);
		ClassRegistry::flush();
	}

}
