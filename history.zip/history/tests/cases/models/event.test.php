<?php
/* Event Test cases generated on: 2012-08-12 08:13:07 : 1344759187*/
App::import('Model', 'Event');

class EventTestCase extends CakeTestCase {
	var $fixtures = array('app.event', 'app.user', 'app.category', 'app.application', 'app.headline', 'app.headline_event');

	function startTest() {
		$this->Event =& ClassRegistry::init('Event');
	}

	function endTest() {
		unset($this->Event);
		ClassRegistry::flush();
	}

}
