<?php
/* Event Fixture generated on: 2012-08-12 08:13:07 : 1344759187 */
class EventFixture extends CakeTestFixture {
	var $name = 'Event';

	var $fields = array(
		'id' => array('type' => 'integer', 'null' => false, 'default' => NULL, 'length' => 10, 'key' => 'primary'),
		'name' => array('type' => 'string', 'null' => false, 'length' => 50, 'collate' => 'utf8_general_ci', 'charset' => 'utf8'),
		'event' => array('type' => 'text', 'null' => false, 'collate' => 'utf8_general_ci', 'charset' => 'utf8'),
		'day' => array('type' => 'integer', 'null' => false, 'length' => 2, 'key' => 'index'),
		'month' => array('type' => 'integer', 'null' => false, 'length' => 2),
		'year' => array('type' => 'integer', 'null' => true, 'default' => '0', 'length' => 10),
		'user_id' => array('type' => 'integer', 'null' => false, 'default' => '0', 'length' => 10, 'key' => 'index'),
		'category_id' => array('type' => 'integer', 'null' => false, 'length' => 2),
		'status' => array('type' => 'integer', 'null' => false, 'default' => '0', 'length' => 1),
		'has_image' => array('type' => 'integer', 'null' => false, 'length' => 1),
		'indexes' => array('PRIMARY' => array('column' => 'id', 'unique' => 1), 'day' => array('column' => array('day', 'month', 'category_id', 'status'), 'unique' => 0), 'user_id' => array('column' => 'user_id', 'unique' => 0)),
		'tableParameters' => array('charset' => 'utf8', 'collate' => 'utf8_general_ci', 'engine' => 'MyISAM')
	);

	var $records = array(
		array(
			'id' => 1,
			'name' => 'Lorem ipsum dolor sit amet',
			'event' => 'Lorem ipsum dolor sit amet, aliquet feugiat. Convallis morbi fringilla gravida, phasellus feugiat dapibus velit nunc, pulvinar eget sollicitudin venenatis cum nullam, vivamus ut a sed, mollitia lectus. Nulla vestibulum massa neque ut et, id hendrerit sit, feugiat in taciti enim proin nibh, tempor dignissim, rhoncus duis vestibulum nunc mattis convallis.',
			'day' => 1,
			'month' => 1,
			'year' => 1,
			'user_id' => 1,
			'category_id' => 1,
			'status' => 1,
			'has_image' => 1
		),
	);
}
